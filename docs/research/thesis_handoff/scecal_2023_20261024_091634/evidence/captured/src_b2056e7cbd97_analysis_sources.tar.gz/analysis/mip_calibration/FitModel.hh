#pragma once
#include "Common.hh"
#include <Math/Factory.h>
#include <Math/Functor.h>
#include <Math/Minimizer.h>
#include <TMath.h>
#include <TF1.h>
#include <TGraph.h>
namespace mip {
// Landau MPV corrected for ROOT's -0.22278298 mode displacement.
inline double density(double x,double w,double mpv,double sigma,int precision=80){
 if(!(w>0&&sigma>0))return 0;
 const double center=mpv+.22278298*w;
 int steps=std::max(precision,int(std::ceil(25*sigma/w)));steps=std::min(steps,1600);
 double dt=10./steps,sum=0;
 for(int j=0;j<steps;++j){double t=-5+(j+.5)*dt;sum+=TMath::Landau(x+sigma*t,center,w,true)*std::exp(-.5*t*t);}
 return sum*dt*.3989422804014327;
}
inline double langau(double*x,double*p){return p[3]*density(x[0],p[0],p[1],p[2]);}
struct InputCondition {Condition c;std::unique_ptr<TH1D>h;};
struct FitSpec{int variant=0,rebin=1,precision=80;double plateauSigmas=-1,upperScale=1,seedScale=1,thresholdShift=0,sigmaScale=1;};
struct BinnedCondition{Condition c;std::vector<double>counts,eff;double total=0;};
class Likelihood {
public:
 std::vector<double>x;std::vector<BinnedCondition>conditions;double width=0,low=0,high=0;int precision=80;
 std::vector<double> shape(const double*p)const {
  std::vector<double>a(x.size()*3);
  int steps=std::min(1600,std::max(precision,int(std::ceil(25*p[2]/p[0]))));
  double dt=10./steps,center=p[1]+.22278298*p[0];
  std::vector<double>offset(steps),weight(steps);
  for(int k=0;k<steps;++k){double t=-5+(k+.5)*dt;offset[k]=p[2]*t;weight[k]=std::exp(-.5*t*t)*dt*.3989422804014327;}
  for(size_t i=0;i<x.size();++i)for(int j=0;j<3;++j){double coordinate=x[i]+(j-1)*width*.3872983346207417,sum=0;for(int k=0;k<steps;++k)sum+=TMath::Landau(coordinate+offset[k],center,p[0],true)*weight[k];a[3*i+j]=sum;}
  return a;
 }
 std::vector<double> expected(const BinnedCondition&c,const std::vector<double>&shape)const {
  std::vector<double>v(x.size());double sum=0;
  for(size_t i=0;i<x.size();++i){v[i]=std::max(1e-300,(shape[3*i]*c.eff[3*i]*5+shape[3*i+1]*c.eff[3*i+1]*8+shape[3*i+2]*c.eff[3*i+2]*5)/18);sum+=v[i];}
  for(double&n:v)n=std::max(1e-300,n*c.total/sum);
  return v;
 }
 double operator()(const double*p)const{auto s=shape(p);double dev=0;for(auto&c:conditions){auto v=expected(c,s);for(size_t i=0;i<v.size();++i){double n=c.counts[i];dev+=2*(v[i]-n+(n>0?n*std::log(n/v[i]):0));}}return std::isfinite(dev)?dev:1e100;}
};
inline Likelihood prepare(const std::vector<InputCondition>&input,const Meta&m,const FitSpec&spec,double maxADC){
 Likelihood q;q.precision=spec.precision;int base=mmr::group(m.CellID)?2:4;int rebin=base*spec.rebin;q.width=2*rebin;
 double limit=maxADC,plateau=0;
 for(auto&i:input)if(i.h->Integral()>0){limit=std::min({limit,(2600-m.pedestal)*i.c.factor,i.h->GetXaxis()->GetXmax()});plateau=std::max(plateau,(m.threshold+spec.plateauSigmas*m.threshold_sigma)*i.c.factor);}
 q.low=spec.plateauSigmas<0?0:plateau;q.high=limit*spec.upperScale;
 if(!(q.high>q.low))return q;
 // Align to existing rebinned edges (-100 origin), keeping whole bins only.
 q.low=-100+std::ceil((q.low+100)/q.width)*q.width;q.high=-100+std::floor((q.high+100)/q.width)*q.width;
 for(double x=q.low+.5*q.width;x<q.high;x+=q.width)q.x.push_back(x);
 for(auto&i:input){BinnedCondition b;b.c=i.c;
  for(double x:q.x){double n=0;int first=i.h->FindFixBin(x-.5*q.width+1e-7);for(int k=0;k<rebin;++k)n+=i.h->GetBinContent(first+k);b.counts.push_back(n);b.total+=n;for(int j=0;j<3;++j){double coordinate=x+(j-1)*q.width*.3872983346207417;double eff=spec.plateauSigmas<0?.5*std::erfc(-((coordinate/i.c.factor-m.threshold-spec.thresholdShift*m.threshold_sigma)/(m.threshold_sigma*spec.sigmaScale))/std::sqrt(2.)):1.;b.eff.push_back(eff);}}
  if(b.total>0)q.conditions.push_back(std::move(b));
 }
 return q;
}
struct Fitted {Result r;Likelihood model;std::vector<double>expected;};
inline Fitted fit(const std::vector<InputCondition>&input,const Meta&m,const mmr::Config&cfg,const FitSpec&spec,double fixedMPV=-1){
 Fitted out;auto&r=out.r;r.CellID=m.CellID;r.variant=spec.variant;r.reason="insufficient_statistics";
 double maxADC=cfg.number(mmr::group(m.CellID)?"fit-max-10":"fit-max-15",mmr::group(m.CellID)?1000:2000);
 out.model=prepare(input,m,spec,maxADC);auto&q=out.model;r.fit_low=q.low;r.fit_high=q.high;r.bin_width=q.width;r.conditions=q.conditions.size();
 double total=0;for(auto&c:q.conditions)total+=c.total;r.chnEntries=int(std::min(total,double(INT_MAX)));
 for(auto&i:input)if(i.h->Integral()>0)r.plateau=std::isfinite(r.plateau)?std::max(r.plateau,(m.threshold+4*m.threshold_sigma)*i.c.factor):(m.threshold+4*m.threshold_sigma)*i.c.factor;
 if(total<cfg.integer("min-fit-hits",200)||q.x.size()<8||q.conditions.empty())return out;
 std::vector<double>sum(q.x.size());for(auto&c:q.conditions)for(size_t i=0;i<sum.size();++i)sum[i]+=c.counts[i];
 // ADC data alone determine the seed. No old/MC MPV enters the fit.
 double modal=q.x[std::max_element(sum.begin(),sum.end())-sum.begin()];double seed=std::clamp(modal*spec.seedScale,2.,q.high*.8);
 double lower[3]={.3,.1,.3},upper[3]={q.high*.4,q.high*.95,q.high*.5};double start[3]={std::max(2.,seed*.12),seed,std::max(2.,seed*.2)};
 auto minimizer=std::unique_ptr<ROOT::Math::Minimizer>(ROOT::Math::Factory::CreateMinimizer("Minuit2","Migrad"));require(bool(minimizer),"Cannot create Minuit2");minimizer->SetMaxFunctionCalls(3500);minimizer->SetMaxIterations(1500);minimizer->SetTolerance(.02);minimizer->SetPrintLevel(-1);minimizer->SetErrorDef(1);
 ROOT::Math::Functor fn([&](const double*p){return q(p);},3);minimizer->SetFunction(fn);
 for(int i=0;i<3;++i)minimizer->SetLimitedVariable(i,i==0?"LandauWidth":i==1?"LandauMPV":"GauSigma",std::clamp(start[i],lower[i]*2,upper[i]*.9),std::max(.2,start[i]*.05),lower[i],upper[i]);
 if(fixedMPV>0){minimizer->SetVariableValue(1,fixedMPV);minimizer->FixVariable(1);}
 bool success=minimizer->Minimize();if(success)minimizer->Hesse();r.status=minimizer->Status();r.covariance=minimizer->CovMatrixStatus();r.edm=minimizer->Edm();r.objective=minimizer->MinValue();auto*p=minimizer->X();auto*e=minimizer->Errors();
 r.LandauWidth=p[0];r.LandauMPV=p[1];r.GauSigma=p[2];r.LandauWidth_error=e[0];r.LandauMPV_error=e[1];r.GauSigma_error=e[2];r.relative_error=e[1]/p[1];r.correlation=0;
 for(int i=0;i<3;++i){if(p[i]-lower[i]<std::max(.02,(upper[i]-lower[i])*.001)||upper[i]-p[i]<std::max(.02,(upper[i]-lower[i])*.001))r.boundary=1;for(int j=0;j<3;++j)r.cov[3*i+j]=minimizer->CovMatrix(i,j);if(i!=1&&e[i]>0&&e[1]>0)r.correlation=std::max(r.correlation,std::abs(r.cov[3*i+1]/(e[i]*e[1])));}
 auto shape=q.shape(p);out.expected.assign(q.x.size(),0);double chi=0;int groups=0;
 for(auto&c:q.conditions){auto expected=q.expected(c,shape);double n=0,mu=0,lastN=0,lastMu=0;bool have=false;
  for(size_t i=0;i<expected.size();++i)if(expected[i]<.001)r.model_outlier_hits+=int(c.counts[i]);
  // Pearson chi2 with adjacent bins pooled to expected >=5, separately per stratum.
  for(size_t i=0;i<expected.size();++i){out.expected[i]+=expected[i];n+=c.counts[i];mu+=expected[i];if(mu>=5){if(have){chi+=(lastN-lastMu)*(lastN-lastMu)/lastMu;++groups;}lastN=n;lastMu=mu;n=mu=0;have=true;}}
  if(have){lastN+=n;lastMu+=mu;chi+=(lastN-lastMu)*(lastN-lastMu)/lastMu;++groups;}
  else if(mu>0){chi+=(n-mu)*(n-mu)/mu;++groups;}
 }
 r.ChiSquare=chi;r.NDF=groups-int(q.conditions.size())-(fixedMPV>0?2:3);
 TF1 convolution("convolution",langau,0,q.high,4);convolution.SetParameters(p[0],p[1],p[2],1);r.convolution_peak=convolution.GetMaximumX(0,q.high);
 r.reason="candidate";r.decision=0;
 auto fail=[&](const std::string&reason,int decision=0){r.reason=reason;r.decision=decision;};
 if(!success||r.status!=0)fail("fit_failed",2);
 else if(r.covariance<3)fail("covariance_unreliable");
 else if(r.NDF<=0)fail("insufficient_chi2_groups");
 else if(r.boundary)fail("parameter_boundary");
 else if(!std::isfinite(r.relative_error)||r.relative_error<=0||r.relative_error>cfg.number("max-relative-error",.05))fail("MPV_error_too_large");
 else if(r.correlation>cfg.number("max-correlation",.98))fail("MPV_width_degeneracy");
 else if(r.model_outlier_hits>=std::max(3.,r.chnEntries*.005))fail("threshold_model_incompatible",2);
 else if(r.ChiSquare/r.NDF>(mmr::group(m.CellID)?2.:1.7))fail("chi2_rejected",2);
 return out;
}
inline void saveFit(TDirectory&d,const Fitted&f,const std::string&name){
 const auto&r=f.r;if(!std::isfinite(r.LandauMPV))return;d.cd();
 TF1 fun((name+"_langau").c_str(),langau,0,r.fit_high,4);fun.SetParameters(r.LandauWidth,r.LandauMPV,r.GauSigma,1);fun.SetParNames("LandauWidth","LandauMPV","GauSigma","density_scale");fun.SetNpx(1600);fun.Save(0,r.fit_high,0,0,0,0);fun.Write();
 TGraph graph(f.model.x.size(),f.model.x.data(),f.expected.data());graph.SetName((name+"_expected").c_str());graph.Write();
 auto h=hist(name+"_used",int(f.model.x.size()),r.fit_low,r.fit_high);for(size_t i=0;i<f.model.x.size();++i){double n=0;for(auto&c:f.model.conditions)n+=c.counts[i];h->SetBinContent(i+1,n);h->SetBinError(i+1,std::sqrt(n));}h->SetEntries(r.chnEntries);h->Write();
}
}
