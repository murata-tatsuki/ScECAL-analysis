#include "FitModel.hh"
int main(int argc,char**argv)try{
 using namespace mip;require(argc==6,"Usage: Fit histograms.root configuration.tsv shard.root worker workers");
 mmr::Config cfg(argv[2]);int worker=std::stoi(argv[4]),workers=std::stoi(argv[5]);require(workers>0&&worker>=0&&worker<workers,"Invalid worker index");fresh(argv[3]);
 auto input=mmr::openFile(argv[1]);auto meta=readMeta(*input);auto conditions=readConditions(*input);auto selected=selection(cfg.text("channels","all"));int mode=cfg.text("temperature-mode","current")=="current"?1:0;
 TFile output(argv[3],"CREATE");require(!output.IsZombie(),"Cannot create shard");Result primary,variant;TTree main("Diagnostics","Candidate values retained regardless of compatibility decision"),variants("FitVariants","0 nominal,1 plateau2,2 plateau3,3 plateau4,4 rebin2,5 upper85,6 seed70,7 seed130,8 threshold+sigma,9 threshold-sigma,width150,10 quadrature160,11 temperature counterpart");primary.branches(main);variant.branches(variants);
 std::ofstream table(std::string(argv[3])+".tsv"),scans(std::string(argv[3])+".variants.tsv");resultHeader(table);resultHeader(scans);
 int index=0;for(auto&[id,m]:meta){if(index++%workers!=worker)continue;primary=Result{};primary.CellID=id;
 if(!selected.count(id)||!m.selected){primary.reason="not_selected";main.Fill();resultRow(table,primary);continue;}
 if(!m.ped_present){primary.reason="missing_pedestal";main.Fill();resultRow(table,primary);continue;}
 if(!(std::isfinite(m.threshold)&&std::isfinite(m.threshold_sigma)&&m.threshold_sigma>0)){primary.reason="missing_threshold";main.Fill();resultRow(table,primary);continue;}
 std::vector<InputCondition>histograms,other;for(auto&c:conditions[id]){auto h=getHist(*input,channelName(id)+"/conditions/"+c.name());(c.mode==mode?histograms:other).push_back({c,std::move(h)});}
 auto fitted=fit(histograms,m,cfg,FitSpec{});primary=fitted.r;auto*d=directory(output,channelName(id));saveFit(*d,fitted,"nominal");
 std::vector<FitSpec>specs={{1,1,80,2},{2,1,80,3},{3,1,80,4},{4,2,80,-1},{5,1,80,-1,.85},{6,1,80,-1,1,.7},{7,1,80,-1,1,1.3},{8,1,80,-1,1,1,1},{9,1,80,-1,1,1,-1,1.5},{10,1,160,-1}};
 bool stable=primary.reason=="candidate";double spread=0;
 if(primary.chnEntries>=cfg.integer("min-fit-hits",200)){
 for(auto&spec:specs){auto alt=fit(histograms,m,cfg,spec);variant=alt.r;variants.Fill();resultRow(scans,variant);saveFit(*d,alt,"variant"+std::to_string(spec.variant));
 if(variant.reason!="candidate")stable=false;
 if(std::isfinite(variant.LandauMPV)&&primary.LandauMPV>0)spread=std::max(spread,std::abs(variant.LandauMPV/primary.LandauMPV-1));else stable=false;
 }
 FitSpec altSpec;altSpec.variant=11;auto alt=fit(other,m,cfg,altSpec);variant=alt.r;variants.Fill();resultRow(scans,variant);saveFit(*d,alt,"temperature_counterpart");
 }
 primary.stability=spread;
 if(primary.reason=="candidate"){
  // A converged extrapolation under the turn-on is never called a measurement.
  if(primary.LandauMPV-2*primary.LandauMPV_error<=primary.plateau+primary.bin_width)primary.reason="MPV_not_observed_above_turnon";
  else if(m.threshold_fallback)primary.reason="threshold_chip_fallback";
  else if(!stable||spread>cfg.number("max-stability",.05))primary.reason="fit_condition_dependence";
  else {
   // Profile widths at +/-20% MPV; flat profiles reveal non-identifiability.
   double xs[3]={primary.LandauMPV*.8,primary.LandauMPV,primary.LandauMPV*1.2},ys[3]={0,0,0};bool identified=true;
   for(int j:{0,2}){auto p=fit(histograms,m,cfg,FitSpec{},xs[j]);ys[j]=p.r.objective-primary.objective;if(p.r.status!=0||!std::isfinite(ys[j])||ys[j]<3.84)identified=false;}
   d->cd();TGraph profile(3,xs,ys);profile.SetName("MPV_profile20percent");profile.Write();
   if(!identified)primary.reason="profile_not_identifiable";else {primary.reason="accepted_direct";primary.decision=1;}
  }
 }
 main.Fill();resultRow(table,primary);
 std::cout<<"cell="<<id<<" n="<<primary.chnEntries<<" MPV="<<primary.LandauMPV<<" decision="<<primary.reason<<std::endl;
 }
 output.cd();main.Write();variants.Write();TNamed("fit_definition","Simultaneous binned Poisson shape likelihood; independent profiled normalization per run/factor stratum; all widths free; fixed data threshold transformed by the same quantized factor as ADC. ChiSquare=Pearson chi2 of adjacent expected>=5 groups; NDF=groups-normalizations-3. No old/MC MPV constraint.").Write();output.Close();require(bool(table)&&bool(scans),"Cannot write fit tables");return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}
