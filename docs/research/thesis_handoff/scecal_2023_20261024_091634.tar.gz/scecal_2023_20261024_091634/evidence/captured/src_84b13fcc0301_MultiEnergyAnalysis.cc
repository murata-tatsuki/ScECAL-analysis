#include <iostream>
#include "HLTailSelection.hh"
#include <fstream>
#include "TROOT.h"
#include "TFile.h"
#include "TMath.h"
#include "TTree.h"
#include "TH1F.h"
#include "TH1S.h"
#include "TH2D.h"
#include "TH2S.h"
#include "TGraph.h"
#include "TGraphErrors.h"
#include "TF1.h"
#include "TLatex.h"
#include "TRandom.h"
#include "TRandom3.h"
#include <vector>
#include <string>
#include <algorithm>
#include <numeric>
#include <unordered_set>
#include <set>
#include <cmath>
#include "TLegend.h"
#include "TLegendEntry.h"
#include "TCanvas.h"
#include "TPad.h"
#include "TKey.h"
#include "TDirectory.h"
#include "TSystem.h"
#include <memory>
#include <limits>
#include "TColor.h"
#include <regex>
#include <functional>
#include <limits>
#include "TH1.h"
#include <map>
#include "weightedSSA.cpp"
#include "showerRaddius.cpp"
#include "langaus.C"				// langaus(chargeH, &fitFunc, &peakP, &peakPError);
// #include "../RawtoRoot/include/EBUdecode.h"
// #include "/megraid01/users/murata_t/scecal/ScECAL_CR/analyseCode/RawtoRoot/include/EBUdecode.h"
// #include "/megraid01/users/data_beamtest_SPS2022/analysis/ECAL_Analysis/include/EBUdecode.h"

using namespace std;


// エネルギー分布を求めるマクロ
// calibを使う


const unordered_set<int> bad_channels = {
  // bad channel の CellID をここに列挙
  1, 5, 13, 14, 33, 10004, 10022, 10030, 10031, 10032, 10033, 10034, 10035, 20029, 20033, 20034, 20035, 30003, 30005, 30009, 30013, 30015, 30023, 30025, 30027, 30028, 30030, 30031, 30032, 30033, 30034, 30035, 40001, 40002, 40003, 40005, 40007, 40009, 40011, 40013, 40015, 40017, 40024, 40025, 40026, 40027, 40028, 40029, 40030, 40032, 40034, 40035, 50003, 50004, 50009, 110010, 110022, 110025, 110030, 110031, 110032, 110033, 110034, 110035, 120029, 120030, 120032, 120035, 130024, 130028, 130030, 130032, 130033, 130034, 130035, 140009, 140015, 140034, 150003, 200001, 200007, 200034, 210024, 210030, 210031, 210032, 210033, 210034, 210035, 220030, 220033, 220034, 220035, 230001, 230012, 230021, 230024, 230025, 230027, 230028, 230030, 230031, 230032, 230033, 230034, 230035, 240018, 240026, 240027, 240029, 240030, 240034, 240035, 250000, 250009, 300008, 310010, 310012, 310028, 310032, 310034, 310035, 330001, 330027, 330029, 330031, 330033, 330034, 330035, 340022, 340032, 340034, 340035, 350005, 350009, 400013, 400014, 400016, 400018, 400020, 400022, 400024, 400025, 400028, 410004, 410005, 410006, 410007, 410009, 410010, 410011, 410012, 410017, 410019, 410020, 410021, 410022, 410023, 410025, 410026, 410027, 410028, 410029, 410030, 410031, 410032, 410033, 410034, 410035, 420000, 420002, 420014, 420020, 420025, 420027, 420033, 420034, 420035, 430017, 430021, 430023, 430024, 430025, 430026, 430027, 430028, 430029, 430030, 430031, 430032, 430033, 430034, 430035, 440000, 440001, 440003, 440005, 440006, 440012, 440016, 440019, 440021, 440023, 440024, 440025, 440026, 440027, 440028, 440029, 440030, 440031, 440032, 440033, 440034, 440035, 450001, 450002, 450003, 450008, 450015, 450017, 450018, 500001, 500002, 500003, 500022, 510011, 510013, 510017, 510023, 510025, 510026, 510027, 510028, 510029, 510030, 510031, 510032, 510033, 510034, 510035, 520003, 520028, 520030, 520033, 520034, 520035, 530001, 530003, 530007, 530009, 530011, 530012, 530013, 530017, 530020, 530021, 530022, 530023, 530024, 530025, 530026, 530027, 530028, 530029, 530030, 530031, 530032, 530033, 530034, 530035, 540011, 540032, 540033, 540034, 540035, 550009, 550010, 600000, 600016, 600025, 600027, 600029, 610021, 610022, 610025, 610029, 610030, 610031, 610032, 610033, 610034, 610035, 620000, 620033, 620034, 620035, 630001, 630003, 630005, 630006, 630007, 630009, 630011, 630013, 630014, 630015, 630016, 630017, 630018, 630019, 630020, 630021, 630022, 630023, 630024, 630025, 630026, 630027, 630028, 630029, 630030, 630031, 630032, 630033, 630034, 630035, 640000, 640001, 640002, 640003, 640005, 640007, 640008, 640010, 640011, 640012, 640013, 640015, 640017, 640018, 640019, 640021, 640022, 640023, 640024, 640025, 640026, 640027, 640028, 640029, 640030, 640032, 640033, 640034, 640035, 650007, 650008, 650009, 650010, 650017, 700000, 700001, 700035, 710001, 710003, 710007, 710009, 710013, 710017, 710019, 710021, 710022, 710023, 710025, 710027, 710028, 710031, 710032, 710034, 710035, 720028, 720029, 720030, 720031, 720032, 720033, 720034, 720035, 730003, 730005, 730006, 730007, 730008, 730009, 730011, 730012, 730014, 730015, 730016, 730017, 730019, 730021, 730022, 730023, 730024, 730025, 730026, 730027, 730029, 730030, 730031, 730032, 730033, 730034, 730035, 740001, 740002, 740007, 740008, 740012, 740027, 740034, 740035, 800001, 800002, 800003, 800004, 800005, 800006, 800016, 800020, 800022, 800030, 800032, 810001, 810003, 810007, 810009, 810010, 810011, 810012, 810013, 810014, 810015, 810017, 810021, 810023, 810025, 810026, 810027, 810028, 810029, 810030, 810031, 810032, 810033, 810034, 810035, 820016, 820017, 820033, 820034, 820035, 830000, 830002, 830003, 830004, 830005, 830007, 830008, 830009, 830011, 830012, 830013, 830015, 830016, 830017, 830018, 830019, 830021, 830023, 830024, 830025, 830027, 830028, 830029, 830030, 830031, 830032, 830033, 830034, 830035, 840000, 840001, 840002, 840003, 840004, 840005, 840007, 840008, 840010, 840012, 840014, 840019, 840020, 840023, 840024, 840025, 840026, 840027, 840028, 840029, 840030, 840031, 840032, 840033, 840034, 840035, 850001, 850002, 850003, 850008, 850009, 850019, 850021, 850022, 850024, 850025, 850027, 850029, 900002, 900015, 910005, 910007, 910021, 910029, 910033, 910034, 910035, 920015, 920016, 920017, 920030, 920033, 920035, 930009, 930015, 930016, 930017, 930018, 930019, 930023, 930024, 930025, 930026, 930027, 930028, 930029, 930030, 930031, 930032, 930033, 930034, 930035, 940001, 940003, 940005, 940029, 940030, 940031, 940033, 940034, 940035, 1000002, 1000004, 1000015, 1000018, 1000020, 1000024, 1000025, 1000026, 1000028, 1000029, 1000030, 1000032, 1000035, 1010001, 1010002, 1010003, 1010005, 1010007, 1010008, 1010012, 1010014, 1010015, 1010017, 1010018, 1010019, 1010020, 1010021, 1010022, 1010023, 1010024, 1010025, 1010027, 1010028, 1010029, 1010030, 1010031, 1010032, 1010033, 1010034, 1010035, 1020002, 1020015, 1020024, 1020032, 1020033, 1020034, 1020035, 1030001, 1030003, 1030004, 1030005, 1030006, 1030007, 1030008, 1030009, 1030010, 1030011, 1030012, 1030013, 1030015, 1030016, 1030017, 1030018, 1030019, 1030020, 1030021, 1030023, 1030024, 1030025, 1030026, 1030027, 1030028, 1030029, 1030030, 1030031, 1030032, 1030033, 1030034, 1030035, 1040000, 1040001, 1040002, 1040003, 1040004, 1040005, 1040006, 1040007, 1040009, 1040010, 1040011, 1040012, 1040013, 1040014, 1040015, 1040016, 1040018, 1040019, 1040021, 1040022, 1040023, 1040024, 1040025, 1040026, 1040027, 1040028, 1040029, 1040030, 1040032, 1040033, 1040034, 1040035, 1050005, 1050009, 1050013, 1100004, 1100005, 1100007, 1100011, 1100024, 1100032, 1110006, 1110014, 1110015, 1110022, 1110024, 1110025, 1110030, 1110031, 1110032, 1110033, 1110034, 1110035, 1120001, 1120015, 1120017, 1120029, 1130003, 1130004, 1130005, 1130007, 1130009, 1130011, 1130015, 1130021, 1130023, 1130025, 1130027, 1130028, 1130029, 1130030, 1130031, 1130032, 1130033, 1130034, 1130035, 1140000, 1140004, 1140007, 1140010, 1140022, 1140025, 1140030, 1140031, 1140032, 1140033, 1140034, 1140035, 1150010, 1150011, 1200003, 1200015, 1200016, 1200018, 1200026, 1210003, 1210007, 1210009, 1210013, 1210015, 1210017, 1210018, 1210019, 1210020, 1210021, 1210022, 1210023, 1210025, 1210027, 1210029, 1210030, 1210031, 1210032, 1210033, 1210034, 1210035, 1220002, 1220024, 1220026, 1220033, 1220034, 1220035, 1230001, 1230003, 1230005, 1230007, 1230015, 1230017, 1230019, 1230021, 1230022, 1230023, 1230025, 1230026, 1230027, 1230029, 1230030, 1230031, 1230032, 1230033, 1230034, 1230035, 1240000, 1240001, 1240002, 1240003, 1240005, 1240006, 1240008, 1240009, 1240010, 1240011, 1240013, 1240014, 1240015, 1240016, 1240017, 1240019, 1240021, 1240022, 1240023, 1240024, 1240025, 1240026, 1240027, 1240028, 1240029, 1240030, 1240032, 1240033, 1240034, 1240035, 1250001, 1250002, 1250006, 1250010, 1250013, 1300001, 1300002, 1300003, 1300004, 1300006, 1300007, 1300009, 1300012, 1300020, 1310004, 1310009, 1310017, 1310019, 1310025, 1310026, 1310027, 1310028, 1310030, 1310031, 1310033, 1310034, 1310035, 1320027, 1320028, 1320029, 1320030, 1320031, 1320032, 1320033, 1320034, 1320035, 1330011, 1330015, 1330017, 1330018, 1330019, 1330020, 1330021, 1330022, 1330023, 1330024, 1330025, 1330026, 1330027, 1330028, 1330029, 1330031, 1330032, 1330033, 1330034, 1330035, 1340007, 1340019, 1340023, 1340028, 1340030, 1340032, 1340033, 1340034, 1340035, 1350006, 1350008, 1350009, 1400005, 1400016, 1400018, 1400020, 1400022, 1400024, 1400026, 1400028, 1400030, 1400032, 1410001, 1410002, 1410004, 1410005, 1410006, 1410007, 1410009, 1410010, 1410013, 1410015, 1410018, 1410019, 1410020, 1410021, 1410022, 1410023, 1410025, 1410027, 1410028, 1410029, 1410030, 1410031, 1410032, 1410033, 1410034, 1410035, 1420000, 1420001, 1420002, 1420015, 1420016, 1420017, 1420031, 1420033, 1420034, 1420035, 1430000, 1430001, 1430003, 1430005, 1430008, 1430010, 1430011, 1430013, 1430015, 1430018, 1430019, 1430021, 1430022, 1430023, 1430025, 1430027, 1430028, 1430029, 1430030, 1430031, 1430032, 1430033, 1430034, 1430035, 1440001, 1440002, 1440003, 1440004, 1440005, 1440006, 1440007, 1440008, 1440009, 1440010, 1440011, 1440012, 1440013, 1440014, 1440015, 1440016, 1440017, 1440018, 1440019, 1440020, 1440021, 1440022, 1440023, 1440024, 1440025, 1440026, 1440027, 1440028, 1440029, 1440030, 1440031, 1440032, 1440033, 1440034, 1440035, 1450000, 1450001, 1450002, 1450004, 1450006, 1450007, 1450022, 1450024, 1450026, 1450027, 1450029, 1500003, 1500006, 1510001, 1510017, 1510029, 1510032, 1510033, 1510034, 1520031, 1520034, 1530000, 1530005, 1530021, 1530022, 1530023, 1530025, 1530027, 1530028, 1530029, 1530030, 1530031, 1530033, 1530034, 1530035, 1540001, 1540011, 1540027, 1540028, 1540032, 1540034, 1540035, 1550009, 1550025, 1600000, 1600012, 1600020, 1600026, 1600030, 1600031, 1600032, 1610000, 1610005, 1610009, 1610011, 1610013, 1610015, 1610017, 1610019, 1610021, 1610022, 1610025, 1610027, 1610029, 1610030, 1610031, 1610032, 1610033, 1610034, 1610035, 1620009, 1620012, 1620013, 1620014, 1620015, 1620016, 1620018, 1620019, 1620020, 1620021, 1620022, 1620024, 1620027, 1620028, 1620030, 1620033, 1620034, 1620035, 1630005, 1630007, 1630009, 1630011, 1630013, 1630015, 1630017, 1630019, 1630023, 1630024, 1630025, 1630026, 1630027, 1630029, 1630030, 1630031, 1630032, 1630033, 1630034, 1630035, 1640002, 1640005, 1640007, 1640009, 1640011, 1640013, 1640015, 1640017, 1640019, 1640021, 1640022, 1640023, 1640026, 1640027, 1640028, 1640029, 1640033, 1640034, 1650003, 1650009, 1650010, 1650011, 1650022, 1650026, 1650027, 1650028, 1650029, 1700001, 1700003, 1700006, 1710004, 1710005, 1710009, 1710013, 1710014, 1710015, 1710019, 1710022, 1710023, 1710025, 1710026, 1710027, 1710029, 1710031, 1710032, 1710033, 1710034, 1710035, 1720029, 1720030, 1720032, 1720033, 1720034, 1720035, 1730001, 1730005, 1730007, 1730009, 1730011, 1730013, 1730016, 1730017, 1730018, 1730020, 1730027, 1730031, 1730032, 1730033, 1730035, 1740000, 1740001, 1740006, 1740026, 1740034, 1750009, 1750010, 1750021, 1800016, 1800020, 1800022, 1800028, 1800029, 1800035, 1810011, 1810015, 1810017, 1810023, 1810025, 1810028, 1810029, 1810030, 1810031, 1810032, 1810033, 1810034, 1810035, 1820016, 1820026, 1820032, 1820033, 1820034, 1820035, 1830001, 1830003, 1830004, 1830005, 1830006, 1830007, 1830009, 1830010, 1830011, 1830012, 1830013, 1830014, 1830015, 1830017, 1830019, 1830020, 1830021, 1830022, 1830023, 1830024, 1830025, 1830027, 1830028, 1830029, 1830030, 1830031, 1830032, 1830033, 1830034, 1830035, 1840001, 1840002, 1840003, 1840004, 1840005, 1840007, 1840008, 1840009, 1840010, 1840011, 1840013, 1840014, 1840015, 1840016, 1840017, 1840018, 1840020, 1840021, 1840022, 1840023, 1840024, 1840025, 1840026, 1840027, 1840028, 1840029, 1840030, 1840032, 1840033, 1840034, 1840035, 1850000, 1850001, 1850003, 1850004, 1850006, 1850007, 1850009, 1850010, 1850024, 1850025, 1900000, 1900001, 1900004, 1900005, 1900006, 1900026, 1910003, 1910007, 1910009, 1910015, 1910017, 1910019, 1910021, 1910022, 1910023, 1910025, 1910026, 1910027, 1910029, 1910030, 1910031, 1910032, 1910033, 1910034, 1910035, 1920016, 1920025, 1920028, 1920029, 1920030, 1920031, 1920032, 1920034, 1920035, 1930009, 1930013, 1930016, 1930018, 1930020, 1930022, 1930023, 1930025, 1930027, 1930028, 1930029, 1930031, 1930032, 1930033, 1930035, 1940000, 1940003, 1940017, 1940026, 1940032, 1940033, 1940034, 1940035, 1950005, 1950009, 1950010, 1950013, 2000000, 2000018, 2000020, 2000022, 2000028, 2010001, 2010002, 2010006, 2010007, 2010008, 2010009, 2010010, 2010011, 2010013, 2010014, 2010015, 2010016, 2010017, 2010018, 2010019, 2010020, 2010021, 2010022, 2010023, 2010025, 2010026, 2010027, 2010028, 2010029, 2010030, 2010031, 2010032, 2010033, 2010034, 2010035, 2020006, 2020015, 2020017, 2020028, 2020029, 2020032, 2020033, 2020034, 2020035, 2030000, 2030001, 2030005, 2030006, 2030007, 2030013, 2030015, 2030017, 2030019, 2030023, 2030024, 2030025, 2030027, 2030029, 2030030, 2030031, 2030032, 2030033, 2030034, 2030035, 2040000, 2040001, 2040002, 2040003, 2040004, 2040007, 2040008, 2040010, 2040011, 2040015, 2040016, 2040017, 2040018, 2040019, 2040020, 2040021, 2040022, 2040023, 2040024, 2040025, 2040026, 2040027, 2040028, 2040029, 2040030, 2040031, 2040032, 2040033, 2040034, 2040035, 2050002, 2050006, 2050009, 2050010, 2050011, 2050012, 2050021, 2050023, 2050029, 2100000, 2100002, 2100003, 2100005, 2100006, 2100023, 2110019, 2110025, 2110027, 2110028, 2110032, 2110034, 2110035, 2120017, 2120031, 2120032, 2120033, 2120034, 2120035, 2130002, 2130007, 2130009, 2130010, 2130011, 2130013, 2130017, 2130019, 2130020, 2130021, 2130023, 2130024, 2130025, 2130026, 2130027, 2130029, 2130030, 2130031, 2130032, 2130033, 2130034, 2130035, 2140019, 2140026, 2140027, 2140030, 2140032, 2140033, 2140034, 2140035, 2150009, 2150010, 2150021, 2200020, 2200022, 2200024, 2210017, 2210019, 2210023, 2210025, 2210027, 2210028, 2210029, 2210030, 2210031, 2210032, 2210033, 2210034, 2210035, 2220000, 2220001, 2220033, 2220034, 2220035, 2230002, 2230007, 2230008, 2230011, 2230015, 2230017, 2230020, 2230023, 2230025, 2230027, 2230028, 2230030, 2230031, 2230032, 2230033, 2230034, 2230035, 2240000, 2240001, 2240002, 2240003, 2240005, 2240006, 2240007, 2240009, 2240011, 2240012, 2240013, 2240014, 2240015, 2240017, 2240018, 2240019, 2240020, 2240021, 2240022, 2240023, 2240024, 2240025, 2240026, 2240027, 2240028, 2240029, 2240030, 2240032, 2240034, 2240035, 2250007, 2250022, 2250026, 2250028, 2300000, 2300001, 2300003, 2300004, 2300006, 2300007, 2300013, 2300033, 2300034, 2310005, 2310007, 2310011, 2310013, 2310015, 2310019, 2310021, 2310023, 2310024, 2310025, 2310026, 2310027, 2310028, 2310029, 2310030, 2310031, 2310032, 2310033, 2310034, 2310035, 2320028, 2320029, 2320031, 2320032, 2320033, 2320034, 2330000, 2330001, 2330003, 2330005, 2330009, 2330010, 2330011, 2330012, 2330015, 2330016, 2330017, 2330018, 2330021, 2330022, 2330023, 2330024, 2330025, 2330026, 2330027, 2330028, 2330029, 2330031, 2330032, 2330033, 2330035, 2340027, 2340030, 2340031, 2340032, 2340033, 2340034, 2340035, 2350008, 2350009, 2350010, 2350021, 2400016, 2400020, 2400022, 2410005, 2410007, 2410010, 2410013, 2410019, 2410023, 2410025, 2410027, 2410029, 2410030, 2410031, 2410032, 2410033, 2410034, 2410035, 2420000, 2420011, 2420015, 2420017, 2420033, 2420034, 2420035, 2430000, 2430001, 2430002, 2430003, 2430005, 2430007, 2430009, 2430011, 2430013, 2430015, 2430017, 2430019, 2430020, 2430021, 2430022, 2430023, 2430024, 2430027, 2430028, 2430029, 2430030, 2430031, 2430032, 2430033, 2430034, 2430035, 2440000, 2440001, 2440002, 2440003, 2440005, 2440007, 2440009, 2440010, 2440011, 2440012, 2440013, 2440014, 2440015, 2440016, 2440017, 2440019, 2440020, 2440021, 2440022, 2440023, 2440024, 2440025, 2440026, 2440027, 2440028, 2440029, 2440030, 2440031, 2440032, 2440033, 2440035, 2450000, 2450001, 2450013, 2450022, 2450023, 2450028, 2450029, 2500000, 2500001, 2500002, 2500003, 2500004, 2500005, 2500006, 2500007, 2500013, 2500014, 2500015, 2500022, 2500034, 2500035, 2510004, 2510010, 2510015, 2510017, 2510019, 2510020, 2510021, 2510022, 2510023, 2510024, 2510025, 2510026, 2510027, 2510028, 2510029, 2510030, 2510031, 2510032, 2510033, 2510034, 2510035, 2520032, 2520033, 2520034, 2530001, 2530003, 2530005, 2530009, 2530011, 2530015, 2530016, 2530019, 2530020, 2530021, 2530022, 2530023, 2530025, 2530026, 2530027, 2530028, 2530029, 2530030, 2530031, 2530032, 2530033, 2530034, 2530035, 2540001, 2540003, 2540008, 2540010, 2540013, 2540014, 2540015, 2540024, 2540025, 2540027, 2540030, 2540031, 2540033, 2540034, 2540035, 2550008, 2550009, 2550015, 2550021, 2600001, 2600003, 2600005, 2600012, 2600018, 2600020, 2600022, 2600024, 2600026, 2600030, 2600032, 2610001, 2610003, 2610004, 2610005, 2610007, 2610011, 2610013, 2610014, 2610015, 2610017, 2610019, 2610020, 2610021, 2610022, 2610023, 2610024, 2610025, 2610027, 2610029, 2610030, 2610031, 2610032, 2610033, 2610034, 2610035, 2620001, 2620015, 2620017, 2620033, 2620034, 2620035, 2630001, 2630003, 2630005, 2630006, 2630007, 2630009, 2630011, 2630012, 2630013, 2630015, 2630017, 2630019, 2630021, 2630022, 2630023, 2630024, 2630025, 2630027, 2630028, 2630029, 2630030, 2630031, 2630032, 2630033, 2630034, 2630035, 2640000, 2640001, 2640002, 2640003, 2640005, 2640006, 2640007, 2640009, 2640010, 2640011, 2640013, 2640015, 2640016, 2640017, 2640019, 2640021, 2640022, 2640023, 2640024, 2640025, 2640026, 2640027, 2640028, 2640029, 2640030, 2640031, 2640032, 2640033, 2640034, 2640035, 2650006, 2650021, 2650023, 2650024, 2650027, 2650028, 2650029, 2700000, 2700002, 2700004, 2700009, 2700012, 2700030, 2700032, 2710000, 2710001, 2710002, 2710003, 2710007, 2710009, 2710013, 2710015, 2710016, 2710019, 2710021, 2710025, 2710026, 2710029, 2710030, 2710032, 2710033, 2710034, 2710035, 2720027, 2720032, 2720033, 2720035, 2730001, 2730005, 2730006, 2730007, 2730009, 2730011, 2730012, 2730013, 2730015, 2730016, 2730019, 2730022, 2730023, 2730025, 2730027, 2730028, 2730029, 2730031, 2730032, 2730033, 2730034, 2730035, 2740009, 2740013, 2740016, 2740030, 2740032, 2740033, 2740034, 2750009, 2750010, 2750011, 2750023, 2800005, 2800018, 2800021, 2800022, 2800032, 2810006, 2810013, 2810018, 2810025, 2810027, 2810028, 2810029, 2810030, 2810031, 2810032, 2810033, 2810034, 2810035, 2820006, 2820016, 2820017, 2820026, 2820033, 2820034, 2820035, 2830001, 2830003, 2830005, 2830007, 2830009, 2830010, 2830011, 2830013, 2830014, 2830015, 2830016, 2830017, 2830019, 2830021, 2830023, 2830025, 2830027, 2830028, 2830029, 2830030, 2830031, 2830032, 2830033, 2830034, 2830035, 2840000, 2840001, 2840002, 2840003, 2840005, 2840013, 2840015, 2840016, 2840019, 2840021, 2840022, 2840023, 2840024, 2840025, 2840026, 2840027, 2840028, 2840029, 2840030, 2840032, 2840033, 2840034, 2840035, 2850009, 2850019, 2900000, 2900001, 2900007, 2910000, 2910007, 2910019, 2910021, 2910022, 2910023, 2910024, 2910027, 2910029, 2910031, 2910032, 2910033, 2910034, 2910035, 2920023, 2920032, 2920033, 2920034, 2920035, 2930016, 2930019, 2930022, 2930023, 2930024, 2930025, 2930026, 2930027, 2930028, 2930029, 2930030, 2930031, 2930032, 2930033, 2930034, 2930035, 2940015, 2940017, 2940022, 2940027, 2940032, 2940034, 2940035, 2950009, 2950012, 3000000, 3000001, 3000002, 3000003, 3000004, 3000005, 3000006, 3000007, 3000008, 3000009, 3000010, 3000011, 3000012, 3000013, 3000014, 3000015, 3000016, 3000017, 3000018, 3000019, 3000020, 3000021, 3000022, 3000023, 3000024, 3000025, 3000026, 3000027, 3000028, 3000029, 3000030, 3000031, 3000032, 3000033, 3000034, 3000035, 3010000, 3010001, 3010002, 3010003, 3010004, 3010005, 3010006, 3010007, 3010008, 3010009, 3010010, 3010011, 3010012, 3010013, 3010014, 3010015, 3010016, 3010017, 3010018, 3010019, 3010020, 3010021, 3010022, 3010023, 3010024, 3010025, 3010026, 3010027, 3010028, 3010029, 3010030, 3010031, 3010032, 3010033, 3010034, 3010035, 3020000, 3020001, 3020002, 3020003, 3020004, 3020005, 3020006, 3020007, 3020008, 3020009, 3020010, 3020011, 3020012, 3020013, 3020014, 3020015, 3020016, 3020017, 3020018, 3020019, 3020020, 3020021, 3020022, 3020023, 3020024, 3020025, 3020026, 3020027, 3020028, 3020029, 3020030, 3020031, 3020032, 3020033, 3020034, 3020035, 3030000, 3030001, 3030002, 3030003, 3030004, 3030005, 3030006, 3030007, 3030008, 3030009, 3030010, 3030011, 3030012, 3030013, 3030014, 3030015, 3030016, 3030017, 3030018, 3030019, 3030020, 3030021, 3030022, 3030023, 3030024, 3030025, 3030026, 3030027, 3030028, 3030029, 3030030, 3030031, 3030032, 3030033, 3030034, 3030035, 3040000, 3040001, 3040002, 3040003, 3040004, 3040005, 3040006, 3040007, 3040008, 3040009, 3040010, 3040011, 3040012, 3040013, 3040014, 3040015, 3040016, 3040017, 3040018, 3040019, 3040020, 3040021, 3040022, 3040023, 3040024, 3040025, 3040026, 3040027, 3040028, 3040029, 3040030, 3040031, 3040032, 3040033, 3040034, 3040035, 3050000, 3050001, 3050002, 3050003, 3050004, 3050005, 3050006, 3050007, 3050008, 3050009, 3050010, 3050011, 3050012, 3050013, 3050014, 3050015, 3050016, 3050017, 3050018, 3050019, 3050020, 3050021, 3050022, 3050023, 3050024, 3050025, 3050026, 3050027, 3050028, 3050029, 3100000, 3100001, 3100002, 3100003, 3100004, 3100005, 3100006, 3100007, 3100008, 3100009, 3100010, 3100011, 3100012, 3100013, 3100014, 3100015, 3100016, 3100017, 3100018, 3100019, 3100020, 3100021, 3100022, 3100023, 3100024, 3100025, 3100026, 3100027, 3100028, 3100029, 3100030, 3100031, 3100032, 3100033, 3100034, 3100035, 3110000, 3110001, 3110002, 3110003, 3110004, 3110005, 3110006, 3110007, 3110008, 3110009, 3110010, 3110011, 3110012, 3110013, 3110014, 3110015, 3110016, 3110017, 3110018, 3110019, 3110020, 3110021, 3110022, 3110023, 3110024, 3110025, 3110026, 3110027, 3110028, 3110029, 3110030, 3110031, 3110032, 3110033, 3110034, 3110035, 3120000, 3120001, 3120002, 3120003, 3120004, 3120005, 3120006, 3120007, 3120008, 3120009, 3120010, 3120011, 3120012, 3120013, 3120014, 3120015, 3120016, 3120017, 3120018, 3120019, 3120020, 3120021, 3120022, 3120023, 3120024, 3120025, 3120026, 3120027, 3120028, 3120029, 3120030, 3120031, 3120032, 3120033, 3120034, 3120035, 3130000, 3130001, 3130002, 3130003, 3130004, 3130005, 3130006, 3130007, 3130008, 3130009, 3130010, 3130011, 3130012, 3130013, 3130014, 3130015, 3130016, 3130017, 3130018, 3130019, 3130020, 3130021, 3130022, 3130023, 3130024, 3130025, 3130026, 3130027, 3130028, 3130029, 3130030, 3130031, 3130032, 3130033, 3130034, 3130035, 3140000, 3140001, 3140002, 3140003, 3140004, 3140005, 3140006, 3140007, 3140008, 3140009, 3140010, 3140011, 3140012, 3140013, 3140014, 3140015, 3140016, 3140017, 3140018, 3140019, 3140020, 3140021, 3140022, 3140023, 3140024, 3140025, 3140026, 3140027, 3140028, 3140029, 3140030, 3140031, 3140032, 3140033, 3140034, 3140035, 3150000, 3150001, 3150002, 3150003, 3150004, 3150005, 3150006, 3150007, 3150008, 3150009, 3150010, 3150011, 3150012, 3150013, 3150014, 3150015, 3150016, 3150017, 3150018, 3150019, 3150020, 3150021, 3150022, 3150023, 3150024, 3150025, 3150026, 3150027, 3150028, 3150029
};

bool cog_position_check(double x, double y, double range=200){
  return (abs(x)<range && abs(y)<range);
}

/*
double CalculateShowerRadiusRMS(const vector<double>& x, const vector<double>& y, const vector<double>& energy){
  // データのサイズチェック
  if (x.empty() || x.size() != y.size() || x.size() != energy.size()) {
    std::cerr << "Warning: Input vector sizes mismatch or empty." << std::endl;
    return -1.0; 
  }

  double E_tot = 0.0;
  double sum_X = 0.0;
  double sum_Y = 0.0;
  size_t n_hits = x.size();

  // 1. 総エネルギーとエネルギー重心(Center of Gravity)の計算
  for (size_t i = 0; i < n_hits; ++i) {
    if (energy[i] <= 0) continue; // ノイズ等による負のエネルギーや0を排除
    E_tot += energy[i];
    sum_X += x[i] * energy[i];
    sum_Y += y[i] * energy[i];
  }

  // 総エネルギーがゼロ（ヒットなし）の場合はエラーを返す
  if (E_tot <= 0.0) return 0.0;

  double X_CoG = sum_X / E_tot;
  double Y_CoG = sum_Y / E_tot;

  // 2. 各軸の分散(Variance)の計算
  double sum_var_X = 0.0;
  double sum_var_Y = 0.0;

  for (size_t i = 0; i < n_hits; ++i) {
    if (energy[i] <= 0) continue;
    sum_var_X += energy[i] * std::pow(x[i] - X_CoG, 2);
    sum_var_Y += energy[i] * std::pow(y[i] - Y_CoG, 2);
  }

  double var_x = sum_var_X / E_tot;
  double var_y = sum_var_Y / E_tot;

  // 3. RMS半径 (R_RMS = sqrt(sigma_x^2 + sigma_y^2)) の計算
  double R_num_RMS = std::sqrt(var_x + var_y);

  // 4. 2次元ガウシアンを仮定してR90へ換算 (R90 ≒ 1.518 * R_RMS)
  double R90 = 1.518 * R_num_RMS;

  return R90;
}
*/


struct nameStrings {
  string dataType   = "data";
  int cog_range     = 200;
  string threshold  = "";

  bool isData       = true;
  int cutIdx        = 0;
  int calibIdx      = 0;
  string label;
  int sampleIndex   = -1; // Non-negative when labels are supplied by the caller.
  int conditionIndex = -1; // Same condition across different CoG selections.
};

// Temporary comparison policy: retain data 200 GeV distributions, but do not
// consume their fit values. Identify data by an explicit path component, never
// by sample order or a caller-supplied display label.
bool SummaryOnlyData200(double energy, const std::string& filename) {
  if (energy != 200) return false;
  const auto path = std::filesystem::path(filename).lexically_normal();
  for (const auto& part : path)
    if (part == "simulation" || part == "mc") return false;
  for (const auto& part : path) if (part == "data") return true;
  return false;
}

bool UsableComparisonFit(const TF1* fit, bool checkErrors = false) {
  if (!fit || fit->GetNpar() < 3) return false;
  for (int parameter : {1, 2}) {
    if (!std::isfinite(fit->GetParameter(parameter)) || fit->GetParameter(parameter) <= 0) return false;
    if (checkErrors && (!std::isfinite(fit->GetParError(parameter)) || fit->GetParError(parameter) < 0)) return false;
  }
  if (checkErrors) {
    const double mean = fit->GetParameter(1), sigma = fit->GetParameter(2);
    return std::isfinite(sigma/mean) && std::isfinite(std::hypot(fit->GetParError(2)/mean,
                                                    (sigma/mean)*(fit->GetParError(1)/mean)));
  }
  return true;
}

nameStrings find_name_of_file(string filePath){
  nameStrings result;
  cout << filePath << "   ";

  if(filePath.find("simulation") != std::string::npos) result.dataType = "sim";
  else result.dataType = "data";

  if(result.dataType == "sim"){
    string path = filePath;
    path.erase(0,path.rfind("simulation")+11);
    path.erase(path.find_first_of("/"),path.length());
    result.threshold = path;
  }

  filePath.erase(0,filePath.find_last_of("_")+1);
  result.cog_range = stoi(filePath);


  map<int, int> cutIds;
  cutIds[200] = 0;
  cutIds[5]   = 1;
  cutIds[10]  = 2;
  cutIds[20]  = 3;
  map<string, int> threIds;
  threIds["threshold"]   = 0;
  threIds["threshold0"]  = 1;
  threIds["threshold50"] = 2;

  result.isData   = (result.dataType == "data");
  result.cutIdx   = cutIds[result.cog_range];
  result.calibIdx = threIds[result.threshold];
  
  return result;
} 


// Color and marker shape identify CoG; line/fill identify the compared condition.
int CoGIndex(int cog){
  switch(cog){ case 200: return 0; case 5: return 1; case 10: return 2; case 20: return 3; }
  throw invalid_argument("Unsupported CoG selection: " + to_string(cog));
}

bool ReadCoG(const string& path, int& cog){
  static const regex suffix("_([0-9]+)mm\\.root$");
  smatch match;
  if(!regex_search(path, match, suffix)) return false;
  cog = stoi(match[1]);
  CoGIndex(cog);
  return true;
}

int CoGColor(int cutIdx){
  const int colors[] = {kAzure+1, kRed+1, kGreen+2, kViolet+1};
  return colors[std::max(0, std::min(cutIdx, 3))];
}

template <typename T>
void ApplyConditionStyle(T* obj, int cutIdx, int condition, int lineWidth, bool isFit){
  if(!obj) return;
  const int filled[] = {20, 21, 22, 33}, open[] = {24, 25, 26, 27};
  const int lines[] = {kSolid, kDotted, kDashed, kDashDotted};
  cutIdx = std::max(0, std::min(cutIdx, 3));
  if(!isFit){
    obj->SetMarkerStyle((condition == 0 ? filled : open)[cutIdx]);
    obj->SetMarkerSize(1.2);
    obj->SetMarkerColor(CoGColor(cutIdx));
  }
  obj->SetLineColor(CoGColor(cutIdx));
  obj->SetLineStyle(lines[condition % 4]);
  obj->SetLineWidth(lineWidth);
}

template <typename T>
void ApplyConfigStyle(T* obj, bool isData, int cutIdx, int calibIdx = 0, int lineWidth = 2, bool isFit = false){
  ApplyConditionStyle(obj, cutIdx, isData ? 0 : 1 + std::max(0, std::min(calibIdx, 2)), lineWidth, isFit);
}

string SampleCaption(const nameStrings& settings){
  if(settings.sampleIndex < 0)
    return settings.dataType + " " + (settings.cog_range == 200 ? string("nocut") : string(Form("%dmm", settings.cog_range)));
  string caption = settings.label;
  caption = regex_replace(caption, regex("CoG[ ]*200[ ]*mm|200[ ]*mm|no cut"), "nocut");
  if(settings.conditionIndex >= 0){
    const string cut = settings.cog_range == 200 ? "nocut" : string(Form("%d mm", settings.cog_range));
    const string compactCut = Form("%dmm", settings.cog_range);
    if(caption.find(cut) == string::npos && caption.find(compactCut) == string::npos) caption += ", " + cut;
  }
  return caption;
}

int SampleColor(int index){
  const int palette[] = {kAzure+1, kOrange+7, kGreen+2, kMagenta+1,
                         kRed+1, kCyan+2, kViolet+1, kGray+2};
  return palette[index % 8];
}

template <typename T>
void ApplySampleStyle(T* obj, const nameStrings& settings, int lineWidth = 2, bool isFit = false){
  if(settings.conditionIndex >= 0){
    ApplyConditionStyle(obj, settings.cutIdx, settings.conditionIndex, lineWidth, isFit);
    return;
  }
  if(settings.sampleIndex < 0){
    ApplyConfigStyle(obj, settings.isData, settings.cutIdx, settings.calibIdx, lineWidth, isFit);
    return;
  }
  if(!obj) return;
  const int index = settings.sampleIndex;
  const int markers[] = {20, 21, 22, 23, 33, 34, 29, 24};
  if(!isFit){
    obj->SetMarkerStyle(markers[index % 8]);
    obj->SetMarkerSize(1.2);
    obj->SetMarkerColor(SampleColor(index));
  }
  obj->SetLineColor(SampleColor(index));
  obj->SetLineStyle(1 + (index / 8) % 4);
  obj->SetLineWidth(lineWidth);
}

// ROOT may cache callback fits while rejected points return zero. Store an
// analytic display function with the fitted parameters so cloning/reopening a
// canvas cannot introduce artificial dips at the excluded fit energies.
void PrepareResolutionFunctions(TList* objects){
  vector<TF1*> fits;
  TIter next(objects);
  while(auto* object=next()){
    if(auto* pad=dynamic_cast<TVirtualPad*>(object)) PrepareResolutionFunctions(pad->GetListOfPrimitives());
    else if(auto* graph=dynamic_cast<TGraph*>(object)) PrepareResolutionFunctions(graph->GetListOfFunctions());
    else if(auto* fit=dynamic_cast<TF1*>(object)) fits.push_back(fit);
  }
  for(auto* fit : fits){
      if(string(fit->GetName()).find("res_func_low_") != 0) continue;
      const char* formula=fit->GetNpar()==3 ? "sqrt([0]*[0]/x+[1]*[1]/(x*x)+[2]*[2])" : "sqrt([0]*[0]/x+[1]*[1])";
      auto* display=new TF1(fit->GetName(), formula, fit->GetXmin(), fit->GetXmax(), TF1::EAddToList::kNo);
      for(int i=0; i<fit->GetNpar(); ++i){
        display->SetParameter(i,fit->GetParameter(i));
        display->SetParError(i,fit->GetParError(i));
        display->SetParName(i,fit->GetParName(i));
        double low, high; fit->GetParLimits(i,low,high); display->SetParLimits(i,low,high);
      }
      display->SetChisquare(fit->GetChisquare()); display->SetNDF(fit->GetNDF());
      display->SetNumberFitPoints(fit->GetNumberFitPoints());
      display->SetLineColor(fit->GetLineColor()); display->SetLineStyle(fit->GetLineStyle());
      display->SetLineWidth(fit->GetLineWidth());
      display->SetNpx(2000);
      display->SetBit(TObject::kMustCleanup);
      for(auto* link=objects->FirstLink(); link; link=link->Next()){
        if(link->GetObject()==fit){ link->SetObject(display); break; }
      }
  }
}

// Copy each graph/curve independently; the legacy source may share objects
// across pads, and subsequent noise fits reuse the original resolution graphs.
void AddResolutionSummaryPanel(TCanvas* summary, TCanvas* source, int index, bool log){
  // ROOT axis updates and PNG export depend on gPad. Restore the caller's pad.
  TVirtualPad::TContext padContext;
  TVirtualPad* sourcePad=source;
  TIter pads(source->GetListOfPrimitives());
  while(auto* object=pads()){
    if(auto* pad=dynamic_cast<TVirtualPad*>(object)){ sourcePad=pad; break; }
  }
  auto* target=summary->cd(index);
  target->SetLeftMargin(.12); target->SetRightMargin(.04);
  target->SetTopMargin(.10); target->SetBottomMargin(.13);
  target->SetLogx(log); target->SetLogy(log); target->SetGrid();
  map<TObject*,TObject*> copies;
  bool first=true;
  TIter graphs(sourcePad->GetListOfPrimitives());
  while(auto* object=graphs()){
    auto* graph=dynamic_cast<TGraph*>(object);
    if(!graph) continue;
    auto* copy=dynamic_cast<TGraph*>(graph->Clone(Form("summary_graph_%d_%zu",index,copies.size())));
    copy->GetListOfFunctions()->Delete(); // Explicit curves below use the same fitted parameters.
    copy->SetBit(TObject::kCanDelete);
    copy->SetMarkerSize(2.2);
    copy->SetTitle(index%2 ? "without noise term" : "with noise term");
    copy->Draw(first ? "AP" : "P same");
    copies[graph]=copy;
    first=false;
  }
  TIter curves(sourcePad->GetListOfPrimitives());
  while(auto* object=curves()){
    if(auto* fit=dynamic_cast<TF1*>(object)) fit->DrawCopy("same");
  }
  if(!log){
    auto* legend=new TLegend(.30,.54,.95,.90);
    legend->SetNColumns(copies.size()>4 ? 2 : 1);
    legend->SetTextFont(42); legend->SetTextSize(0);
    legend->SetBorderSize(0); legend->SetFillColorAlpha(kWhite,.8);
    legend->SetMargin(.12); legend->SetEntrySeparation(.3);
    legend->SetBit(TObject::kCanDelete);
    TIter objects(sourcePad->GetListOfPrimitives());
    while(auto* object=objects()){
      auto* original=dynamic_cast<TLegend*>(object);
      if(!original) continue;
      TIter entries(original->GetListOfPrimitives());
      while(auto* entryObject=entries()){
        auto* entry=dynamic_cast<TLegendEntry*>(entryObject);
        if(!entry) continue;
        auto copy=copies.find(entry->GetObject());
        legend->AddEntry(copy==copies.end() ? nullptr : copy->second,entry->GetLabel(),entry->GetOption());
      }
    }
    legend->Draw();
  }
  target->Modified(); target->Update();
}

// Serialize linear and log views without recalculating points or fits.
// Linear canvases retain their axes in the saved ROOT.
void SaveResolutionViews(TCanvas* canvas, TFile& output, const string& figures, const string& name, TCanvas* summary){
  TVirtualPad::TContext padContext;
  canvas->cd();
  PrepareResolutionFunctions(canvas->GetListOfPrimitives());
  auto visit = [](TVirtualPad* root, const function<void(TVirtualPad*, TGraph*)>& action){
    function<void(TVirtualPad*)> walk = [&](TVirtualPad* pad){
      TVirtualPad::TContext graphContext;
      pad->cd();
      TIter next(pad->GetListOfPrimitives());
      while(auto* object = next()){
        if(auto* child = dynamic_cast<TVirtualPad*>(object)) walk(child);
        else if(auto* graph = dynamic_cast<TGraph*>(object)) action(pad, graph);
      }
    };
    walk(root);
  };
  double xmin = numeric_limits<double>::infinity(), xmax = 130;
  double ymin = numeric_limits<double>::infinity(), ymax = .3;
  visit(canvas, [&](TVirtualPad* pad, TGraph* graph){
    for(int i=0; i<graph->GetN(); ++i){
      const double x=graph->GetPointX(i), y=graph->GetPointY(i);
      if(isfinite(x) && x>0){ xmin=std::min(xmin, .8*x); xmax=std::max(xmax, 1.1*x); }
      if(isfinite(y) && y>0){
        ymin=std::min(ymin, .5*y);
        const auto* errors=dynamic_cast<TGraphErrors*>(graph);
        const double error=errors ? errors->GetErrorY(i) : 0;
        ymax=std::max(ymax, 1.15*(y+(isfinite(error) ? std::abs(error) : 0)));
      }
    }
    pad->SetLogx(0); pad->SetLogy(0);
    graph->SetMinimum(0); graph->SetMaximum(.3);
    graph->GetXaxis()->SetRange(0,0); graph->GetXaxis()->SetLimits(0,130);
    pad->Modified();
  });
  canvas->Modified(); canvas->Update();
  bool divided=false;
  TIter primitives(canvas->GetListOfPrimitives());
  while(auto* object=primitives()) if(dynamic_cast<TVirtualPad*>(object)) divided=true;
  // Legacy panels share graphs: serialize them before/after axis changes,
  // then restore the original axes without cloning their shared ownership.
  // Single-panel comparisons redraw a snapshot for the external legend.
  unique_ptr<TCanvas> snapshot;
  TCanvas* view=canvas;
  if(!divided){
    snapshot.reset(dynamic_cast<TCanvas*>(canvas->Clone((name+"_views").c_str())));
    if(!snapshot) throw runtime_error("Cannot clone resolution canvas");
    view=snapshot.get();
    view->cd();
    view->Modified(); view->Update();
  }
  output.cd(); view->Write(name.c_str());
  view->SaveAs((figures+"/"+name+".png").c_str());
  AddResolutionSummaryPanel(summary,view,name=="resolution" ? 1 : 2,false);
  if(!isfinite(xmin)) xmin=.1;
  if(!isfinite(ymin)) ymin=.001;
  visit(view, [&](TVirtualPad* pad, TGraph* graph){
    pad->SetLogx(1); pad->SetLogy(1);
    graph->SetMinimum(ymin); graph->SetMaximum(ymax);
    graph->GetXaxis()->SetRange(0,0); graph->GetXaxis()->SetLimits(xmin,xmax);
    pad->Modified();
  });
  view->cd();
  view->Modified(); view->Update();
  output.cd(); view->Write((name+"_loglog").c_str());
  view->SaveAs((figures+"/"+name+"_loglog.png").c_str());
  AddResolutionSummaryPanel(summary,view,name=="resolution" ? 3 : 4,true);
  if(divided){
    visit(view, [](TVirtualPad* pad, TGraph* graph){
      pad->SetLogx(0); pad->SetLogy(0);
      graph->SetMinimum(0); graph->SetMaximum(.3);
      graph->GetXaxis()->SetRange(0,0); graph->GetXaxis()->SetLimits(0,130);
      pad->Modified();
    });
  }
}

TLegend* CreateNiceLegend(double x1, double y1, double x2, double y2, int nCols = 2) {
  TLegend *leg = new TLegend(x1, y1, x2, y2);
  
  leg->SetNColumns(nCols);             // 列数の指定（2〜4列が見やすい）
  leg->SetBorderSize(0);               // 黒い枠線を消す
  
  // 【背景設定】グラフの線と被らないように「80%透過の白」にする（完全透明なら SetFillStyle(0)）
  leg->SetFillColorAlpha(kWhite, 0.8); 
  
  leg->SetTextFont(42);                // Helvetica（論文標準の綺麗なノンセリフ体）
  leg->SetTextSize(0.03);              // 文字サイズを適切に指定
  
  return leg;
};

TLegend* CreateSampleLegend(int samples){
  TLegend* legend = CreateNiceLegend(0.32, std::max(0.2, 0.88-0.07*samples), 0.92, 0.88, 1);
  legend->SetMargin(0.12);
  legend->SetEntrySeparation(0.5);
  legend->SetTextSize(0); // ROOT fits arbitrary caller-supplied labels into this box.
  return legend;
}

// Use a common bin width for every sample of a channel. The IQR-based width is
// robust to the long edep tail; cap the display at 40-200 bins over the full range.
int ChannelEnergyRebinFactor(const vector<TH1*>& histograms){
  const TH1* reference = histograms.front();
  const int bins = reference->GetNbinsX();
  const double low = reference->GetXaxis()->GetXmin();
  const double high = reference->GetXaxis()->GetXmax();
  const double span = high-low;
  double width = span/200.;
  bool populated = false;
  for(TH1* hist : histograms){
    if(hist->GetNbinsX() != bins || hist->GetXaxis()->GetXmin() != low ||
       hist->GetXaxis()->GetXmax() != high || hist->GetXaxis()->GetXbins()->GetSize() != 0){
      cerr << "Incompatible channel histogram binning: " << hist->GetName() << endl;
      return 0;
    }
    const double entries = hist->Integral(1, bins);
    if(entries <= 0) continue;
    populated = true;
    double candidate = span/40.;
    if(entries >= 20){
      double quantiles[2], probabilities[2] = {0.25, 0.75};
      hist->GetQuantiles(2, quantiles, probabilities);
      candidate = 2.*(quantiles[1]-quantiles[0])/std::cbrt(entries);
      if(!(candidate > 0)) candidate = 3.5*hist->GetStdDev()/std::cbrt(entries);
    }
    if(std::isfinite(candidate)) width = std::max(width, candidate);
  }
  if(!populated) width = span/100.;
  width = std::max(span/200., std::min(span/40., width));
  int bestFactor = 1;
  double bestDistance = std::numeric_limits<double>::infinity();
  for(int factor=1; factor<=bins; ++factor){
    if(bins%factor != 0) continue; // Never move leftover bins into overflow.
    const int displayedBins = bins/factor;
    if(displayedBins < 40 || displayedBins > 200) continue;
    const double distance = std::abs(std::log((span/displayedBins)/width));
    if(distance < bestDistance){
      bestDistance = distance;
      bestFactor = factor;
    }
  }
  return bestFactor;
}

// SingleEnergy stores per-channel histograms inside its 6x6 raw canvases.
// Read one layer/chip at a time so memory does not grow with the number of canvases.
bool SaveChannelEnergyPair(TFile* const* inputs, int samples, const nameStrings* settings,
                           double energy, TDirectory& output, const char* figurePath){
  TDirectory::TContext restoreDirectory;
  const bool normalize = true;
  const int layers = 30, chips = 6, channels = 36;
  const string energyName = Form("%gGeV", energy);
  const string rawPath = string(figurePath) + "/" + energyName + "/raw";
  if(gSystem->mkdir(rawPath.c_str(), true) != 0 && gSystem->AccessPathName(rawPath.c_str())){
    cerr << "Cannot create channel comparison directory: " << rawPath << endl;
    return false;
  }
  bool renderAfterCut = true;
  vector<TDirectory*> inputDirectories(samples);
  vector<int> colors(samples);
  for(int ds=0; ds<samples; ++ds){
    inputDirectories[ds] = inputs[ds]->GetDirectory(energyName.c_str());
    // Older SingleEnergy files truncate the directory name for fractional beam energies.
    if(!inputDirectories[ds]) inputDirectories[ds] = inputs[ds]->GetDirectory(Form("%dGeV", int(energy)));
    if(!inputDirectories[ds]){
      cerr << "Missing channel energy directory for " << energyName << " in " << inputs[ds]->GetName() << endl;
      return false;
    }
    colors[ds] = settings[ds].conditionIndex >= 0 || settings[ds].sampleIndex < 0
                   ? CoGColor(settings[ds].cutIdx) : SampleColor(settings[ds].sampleIndex);
    // Check all raw canvases before starting to render this energy.
    for(const char* prefix : {"", "cut_"}){
      for(int layer=0; layer<layers; ++layer){
        for(int chip=0; chip<chips; ++chip){
          const string key = Form("%sedep_Layer%d_Chip%d", prefix, layer, chip);
          if(!inputDirectories[ds]->GetKey(key.c_str())){
            auto* status = dynamic_cast<TNamed*>(inputs[ds]->Get("hl_tail_status"));
            if (*prefix && SummaryOnlyData200(energy, inputs[ds]->GetName()) && status &&
                std::string(status->GetTitle()) == "incomplete") {
              renderAfterCut = false;
              continue;
            }
            cerr << "Missing raw canvas " << key << " in " << inputs[ds]->GetName() << endl;
            return false;
          }
        }
      }
    }
  }
  TDirectory* energyDirectory = output.GetDirectory(energyName.c_str());
  if(!energyDirectory) energyDirectory = output.mkdir(energyName.c_str());
  TDirectory* rawDirectory = energyDirectory->GetDirectory("raw");
  if(!rawDirectory) rawDirectory = energyDirectory->mkdir("raw");
  if (!renderAfterCut)
    cerr << "Skipping unavailable after-cut channel comparison for " << energyName
         << "; incomplete summary-only data 200 GeV input" << endl;
  for(int eventCut=0; eventCut<2; ++eventCut){
    if (eventCut && !renderAfterCut) continue;
    const char* prefix = eventCut ? "cut_" : "";
    for(int layer=0; layer<layers; ++layer){
      cout << "Channel edep: " << energyName << ", " << (eventCut ? "after" : "before")
           << " event cut, layer " << layer << "/" << layers-1 << endl;
      for(int chip=0; chip<chips; ++chip){
        const string key = Form("%sedep_Layer%d_Chip%d", prefix, layer, chip);
        vector<vector<unique_ptr<TH1>>> histograms(samples);
        for(int ds=0; ds<samples; ++ds){
          TDirectory::TContext inputContext(inputDirectories[ds]);
          unique_ptr<TObject> stored(inputDirectories[ds]->GetKey(key.c_str())->ReadObj());
          TCanvas* source = dynamic_cast<TCanvas*>(stored.get());
          if(!source){
            cerr << "Raw object is not a canvas: " << key << " in " << inputs[ds]->GetName() << endl;
            return false;
          }
          for(int channel=0; channel<channels; ++channel){
            const string histName = Form("edep_channel_%d_%d_%d", layer, chip, channel);
            TVirtualPad* pad = source->GetPad(channel+1);
            TH1* original = pad ? dynamic_cast<TH1*>(pad->GetListOfPrimitives()->FindObject(histName.c_str())) : nullptr;
            if(!original){
              cerr << "Missing histogram " << histName << " in " << inputs[ds]->GetName() << ":" << key << endl;
              return false;
            }
            unique_ptr<TH1> hist(static_cast<TH1*>(original->Clone(Form("%s_ds%d", histName.c_str(), ds))));
            hist->SetDirectory(nullptr);
            hist->ResetBit(TObject::kCanDelete);
            hist->GetXaxis()->SetRange(0, 0);
            hist->SetStats(false);
            hist->SetTitle(Form("channel %d", channel));
            hist->GetXaxis()->SetTitle("Hit energy [MeV]");
            hist->GetYaxis()->SetTitle(normalize ? "Normalized entries" : "Entries");
            ApplySampleStyle(hist.get(), settings[ds], 2);
            hist->SetLineColor(colors[ds]);
            hist->SetMarkerColor(colors[ds]);
            histograms[ds].push_back(std::move(hist));
          }
        }
        const string canvasName = Form("channel_comparison_%s_%s", energyName.c_str(), key.c_str());
        unique_ptr<TCanvas> canvas(new TCanvas(canvasName.c_str(), canvasName.c_str(), 2560, 1440));
        canvas->SetCanvasSize(2560, 1440); // Fix drawable/PNG size independently of window borders.
        canvas->Divide(6, 6);
        const int columns = std::min(samples, 4);
        const int rows = (samples+columns-1)/columns;
        const double legendBottom = 0.952 - 0.032*rows;
        const double plotTop = legendBottom-0.012;
        for(int channel=0; channel<channels; ++channel){
          TPad* pad = static_cast<TPad*>(canvas->cd(channel+1));
          pad->SetPad(pad->GetXlowNDC(), plotTop*pad->GetYlowNDC(),
                      pad->GetXlowNDC()+pad->GetWNDC(), plotTop*(pad->GetYlowNDC()+pad->GetHNDC()));
          vector<TH1*> channelHistograms;
          for(int ds=0; ds<samples; ++ds) channelHistograms.push_back(histograms[ds][channel].get());
          const int factor = ChannelEnergyRebinFactor(channelHistograms);
          if(factor == 0) return false;
          double maximum = 0;
          for(TH1* hist : channelHistograms){
            if(factor > 1) hist->Rebin(factor);
            const double integral = hist->Integral(1, hist->GetNbinsX());
            if(normalize && integral > 0) hist->Scale(1./integral);
            hist->SetTitle(Form("channel %d (rebin %d)", channel, factor));
            maximum = std::max(maximum, hist->GetMaximum());
          }
          histograms[0][channel]->SetMinimum(0);
          histograms[0][channel]->SetMaximum(maximum > 0 ? 1.15*maximum : 1.);
          for(int ds=0; ds<samples; ++ds) histograms[ds][channel]->Draw(ds == 0 ? "HIST" : "HIST SAME");
          if(maximum == 0){
            TLatex empty;
            empty.SetNDC();
            empty.SetTextSize(0.07);
            empty.DrawLatex(0.4, 0.5, "no entries");
          }
        }
        canvas->cd();
        TLatex title;
        title.SetNDC();
        title.SetTextFont(42);
        title.SetTextSize(0.025);
        title.DrawLatex(0.02, 0.972, Form("%g GeV, layer %d, chip %d; %s event cut; %s",
          energy, layer, chip, eventCut ? "after" : "before", normalize ? "unit area (0-2 MeV)" : "raw entries"));
        unique_ptr<TLegend> legend(CreateNiceLegend(0.02, legendBottom, 0.98, 0.952, columns));
        legend->SetFillStyle(0);
        legend->SetTextSize(0.021);
        legend->SetMargin(0.12);
        for(int ds=0; ds<samples; ++ds){
          const string cut = settings[ds].cog_range == 200 ? "nocut" : Form("%d mm", settings[ds].cog_range);
          const string sample = settings[ds].isData ? "data" : "sim " + settings[ds].threshold;
          const string caption = settings[ds].sampleIndex >= 0 ? SampleCaption(settings[ds]) : sample + ", CoG " + cut;
          legend->AddEntry(histograms[ds][0].get(), caption.c_str(), "l");
        }
        legend->Draw();
        canvas->Modified();
        canvas->Update();
        rawDirectory->cd();
        canvas->Write(key.c_str());
        canvas->SaveAs(Form("%s/%s%gGeV_layer%dchip%d.png", rawPath.c_str(), prefix, energy, layer, chip));
        canvas.reset();
      }
    }
  }
  return true;
}

// Match by CoG selection, not by input order. Each threshold is compared separately.
// Keep the SingleEnergy PNG names and put the condition in directories instead.
bool SaveChannelEnergyComparisons(TFile* const* inputs, int samples, const nameStrings* settings,
                                 double energy, TFile& output, const char* figurePath){
  TDirectory::TContext restoreDirectory;
  if(settings[0].sampleIndex >= 0){
    TDirectory* directory = output.GetDirectory("samples");
    if(!directory) directory = output.mkdir("samples");
    const string path = string(figurePath) + "/samples";
    return SaveChannelEnergyPair(inputs, samples, settings, energy, *directory, path.c_str());
  }
  vector<pair<int, int>> pairs;
  vector<bool> matched(samples, false);
  set<pair<int, string>> conditions;
  for(int sim=0; sim<samples; ++sim){
    if(settings[sim].isData) continue;
    int data = -1;
    for(int candidate=0; candidate<samples; ++candidate){
      if(!settings[candidate].isData || settings[candidate].cog_range != settings[sim].cog_range) continue;
      if(data != -1){
        cerr << "Multiple data samples for CoG " << settings[sim].cog_range << " mm; cannot select a unique pair" << endl;
        return false;
      }
      data = candidate;
    }
    if(data == -1){
      cerr << "No matching data for " << inputs[sim]->GetName() << " (CoG " << settings[sim].cog_range << " mm)" << endl;
      return false;
    }
    if(!conditions.emplace(settings[sim].cog_range, settings[sim].threshold).second){
      cerr << "Duplicate simulation condition: CoG " << settings[sim].cog_range
           << " mm, " << settings[sim].threshold << endl;
      return false;
    }
    pairs.emplace_back(data, sim);
    matched[data] = matched[sim] = true;
  }
  for(int ds=0; ds<samples; ++ds){
    if(!matched[ds]){
      cerr << "No matching simulation for " << inputs[ds]->GetName()
           << " (CoG " << settings[ds].cog_range << " mm)" << endl;
      return false;
    }
  }
  for(const auto& pair : pairs){
    TFile* pairInputs[2] = {inputs[pair.first], inputs[pair.second]};
    const nameStrings pairSettings[2] = {settings[pair.first], settings[pair.second]};
    const string cogName = Form("cog%dmm", pairSettings[0].cog_range);
    const string thresholdName = pairSettings[1].threshold.empty() ? "simulation" : pairSettings[1].threshold;
    const string pairPath = string(figurePath) + "/" + cogName + "/" + thresholdName;
    TDirectory* cogDirectory = output.GetDirectory(cogName.c_str());
    if(!cogDirectory) cogDirectory = output.mkdir(cogName.c_str());
    TDirectory* pairDirectory = cogDirectory->GetDirectory(thresholdName.c_str());
    if(!pairDirectory) pairDirectory = cogDirectory->mkdir(thresholdName.c_str());
    cout << "Channel comparison pair: " << cogName << "/" << thresholdName << endl;
    if(!SaveChannelEnergyPair(pairInputs, 2, pairSettings, energy, *pairDirectory, pairPath.c_str())) return false;
  }
  return true;
}

int CalculateRebinFactor(const TH1* h, double sigma) {
  // cout << sigma  << endl;
    // 安全対策：ヌルポインタや不適切な値の場合は 1 (Rebinなし) を返す
    if (!h || sigma <= 0.0) return 1;

    // 1. ヒストグラムから現在の 1 ビンの幅を取得 (第1ビンの幅)
    double currentBinWidth = h->GetBinWidth(1);
    if (currentBinWidth <= 0.0) return 1;

    // 2. 目標とするビン幅を計算 (例: sigma / 5.0)
    double targetBinWidth = sigma / 10.0;

    // 3. Rebin Factor (何個のビンを1つにまとめるか) を計算して四捨五入
    int rebinFactor = static_cast<int>(std::floor(targetBinWidth / currentBinWidth));

    // 4. 最低でも 1 (Rebin しない) を保証する
    return std::max(1, rebinFactor);
}

int CalculateLandauRebinFactor(const TH1* h, int targetBinsOnRise = 10) {
    if (!h) return 1;

    int maxBin = h->GetMaximumBin();
    double maxVal = h->GetBinContent(maxBin);
    double halfMax = maxVal / 2.0;

    // ピークより左側に向かって Half Maximum となるビンを探す
    int halfMaxBin = maxBin;
    for (int b = maxBin; b >= 1; --b) {
        if (h->GetBinContent(b) <= halfMax) {
            halfMaxBin = b;
            break;
        }
    }

    // 立ち上がり部分の現在のビン数
    int currentBinsOnRise = maxBin - halfMaxBin;
    if (currentBinsOnRise <= 0) return 1;

    // 目標のビン数（例: 8ビン）になるように Rebin Factor を計算
    int rebinFactor = currentBinsOnRise / targetBinsOnRise;

    return std::max(1, rebinFactor);
}

int main(int argc, char* argv[]) try
{ 
    if(argc < 6){
        cout << "usage: MultiEnergyAnalysis output.root N_samples N_files files... figure_path [--labels label1 ... labelN] [--skip-channel-plots] [--exclude-tail-events|--keep-tail-events|--compare-tail-selections]" << endl;
        return 1;
    }
  gROOT->SetBatch(kTRUE);

    //cout << argv[1] << endl;
	cout << "=====>  " << argv[1] << endl;
  
  int rawfilenum = 0, Ndatasim = 0;
  try {
    size_t countEnd, samplesEnd;
    rawfilenum = stoi(argv[3], &countEnd);
    Ndatasim = stoi(argv[2], &samplesEnd);
    if(countEnd != string(argv[3]).size() || samplesEnd != string(argv[2]).size() ||
       rawfilenum <= 0 || Ndatasim < 2) throw invalid_argument("counts");
  } catch(const exception&){
    cerr << "Require at least two samples and a positive file count per sample" << endl;
    return 1;
  }
  const long long positionalArgc = 5LL + 1LL * Ndatasim * rawfilenum;
  if(positionalArgc > argc){
    cerr << "Number of files does not match N_samples * N_files" << endl;
    return 1;
  }
  vector<string> labels;
  bool skipChannelPlots = false;
  bool excludeTailEvents = true, tailModeSpecified = false, compareTailSelections = false;
  for(int argument = int(positionalArgc); argument < argc;){
    const string option = argv[argument++];
    if(option == "--labels" && labels.empty()){
      if(argc - argument < Ndatasim){
        cerr << "--labels requires one label per sample" << endl;
        return 1;
      }
      for(int ds=0; ds<Ndatasim; ++ds){
        const string label = argv[argument++];
        if(label.empty() || label.compare(0, 2, "--") == 0){
          cerr << "Labels must be non-empty and must not start with --" << endl;
          return 1;
        }
        labels.push_back(label);
      }
    } else if(option == "--exclude-tail-events" || option == "--keep-tail-events"){
      hl_tail::require(!tailModeSpecified, "specify one tail selection option");
      tailModeSpecified = true;
      excludeTailEvents = option == "--exclude-tail-events";
    } else if(option == "--compare-tail-selections"){
      hl_tail::require(!compareTailSelections, "repeated --compare-tail-selections");
      compareTailSelections = true;
    } else if(option == "--skip-channel-plots"){
      skipChannelPlots = true;
    } else {
      cerr << "Unknown or repeated option: " << option << endl;
      return 1;
    }
  }
  hl_tail::require(!(compareTailSelections && tailModeSpecified),
                   "--compare-tail-selections cannot be combined with an exclude/keep option");
  hl_tail::require(!compareTailSelections || !labels.empty(),
                   "--compare-tail-selections requires explicit --labels for each series");
  const bool customLabels = !labels.empty();
  // Keep the original positional interface and figure-path references below.
  argc = int(positionalArgc);

  vector<pair<double,int>> filenames[Ndatasim];
  for(int ii=0; ii<Ndatasim; ii++){
    for(int i=0; i<rawfilenum; i++){
      int index = i + 4 + ii * rawfilenum;
      string txtname(argv[index]);
      txtname.erase(0,txtname.find_last_of("/")+1);
      // txtname.erase(txtname.find_last_of("_"),txtname.end()-1);
      try {
        const double energy = stod(txtname);
        if(!isfinite(energy) || energy <= 0) throw invalid_argument("energy");
        filenames[ii].push_back({energy, index});
      } catch(const exception&){
        cerr << "Input filename must start with a positive beam energy: " << argv[index] << endl;
        return 1;
      }
      // cout << argv[index] << ",  " << stod(txtname) << endl;
    }
  }
  for(int ii=0; ii<Ndatasim; ii++) sort(filenames[ii].begin(),filenames[ii].end());
  for(int ds=0; ds<Ndatasim; ++ds){
    for(int i=0; i<rawfilenum; ++i){
      if(i > 0 && filenames[ds][i-1].first == filenames[ds][i].first){
        cerr << "Duplicate beam energy in sample " << ds+1 << ": " << filenames[ds][i].first << endl;
        return 1;
      }
      if(filenames[ds][i].first != filenames[0][i].first){
        cerr << "Beam energies do not match for sample " << ds+1 << endl;
        return 1;
      }
    }
  }
  for(int argument=4; argument<argc-1; ++argument){
    if(string(argv[argument]) == argv[1]){
      cerr << "Output must not overwrite an input file" << endl;
      return 1;
    }
  }
  // Mixed comparisons are explicit; each series must still have one selection at all energies.
  vector<int> sampleTailSelection(Ndatasim, -1);
  for (int ds = 0; ds < Ndatasim; ++ds) {
    for (const auto& item : filenames[ds]) {
      const int argument = item.second;
      hl_tail::require(std::filesystem::weakly_canonical(argv[1]) != std::filesystem::weakly_canonical(argv[argument]),
                       "output would overwrite input");
      auto input = hl_tail::open(argv[argument]);
      int selection = int(excludeTailEvents);
      if (compareTailSelections) {
        selection = hl_tail::object<TParameter<int>>(*input, "hl_tail_excluded")->GetVal();
        hl_tail::require(selection == 0 || selection == 1, "expected SingleEnergy selection flag 0 or 1");
      }
      if (SummaryOnlyData200(item.first, argv[argument])) {
        // Only this explicitly excluded input may be incomplete. Histograms
        // required by the summary are still checked below before drawing.
        auto* flag = dynamic_cast<TParameter<int>*>(input->Get("hl_tail_excluded"));
        hl_tail::require(flag ? flag->GetVal() == selection : selection == 0,
                         "tail selection mismatch in summary-only input " + std::string(argv[argument]));
        if (flag) {
          const std::string status = hl_tail::object<TNamed>(*input, "hl_tail_status")->GetTitle();
          hl_tail::require(status == "complete" || status == "incomplete", "invalid summary-only analysis status");
        }
        cout << "Summary only (excluded from resolution values): " << argv[argument] << endl;
      } else {
        hl_tail::checkAnalysis(*input, selection == 1);
      }
      hl_tail::require(sampleTailSelection[ds] == -1 || sampleTailSelection[ds] == selection,
                       "tail selection changes across energies in sample " + std::to_string(ds+1));
      sampleTailSelection[ds] = selection;
    }
  }
  if(gSystem->mkdir(argv[argc-1], true) != 0 && gSystem->AccessPathName(argv[argc-1])){
    cerr << "Cannot create figure directory: " << argv[argc-1] << endl;
    return 1;
  }
  

	// int rawfilenum = argc - 2 - 2*rawfilenum - 3;
  // int irawfilenum = 3 + 2*rawfilenum;

	// double cycleID, triggerID;
	// vector<int> *cellIDs = nullptr;
	// vector<int> *BCIDs = nullptr;
	// vector<int> *hitTags = nullptr;
	// vector<int> *gainTags = nullptr;
	// vector<double> *charges = nullptr;
	// vector<double> *times = nullptr;
	// vector<double> *temp = nullptr;
	// vector<double> *posX = nullptr;
	// vector<double> *posY = nullptr;
	// vector<double> *posZ = nullptr;

	// double cycleID_ssa, triggerID_ssa;
	// vector<int> *cellIDs_ssa = nullptr;
	// vector<int> *BCIDs_ssa = nullptr;
	// vector<int> *hitTags_ssa = nullptr;
	// vector<int> *gainTags_ssa = nullptr;
	// vector<double> *charges_ssa = nullptr;
	// vector<double> *times_ssa = nullptr;
	// vector<double> *temp_ssa = nullptr;
	// vector<double> *posX_ssa = nullptr;
	// vector<double> *posY_ssa = nullptr;
	// vector<double> *posZ_ssa = nullptr;
	// vector<int> *ssaTag_ssa = nullptr;

  double EnergyDep;
  vector<int> *cellID = nullptr;
  vector<double> *Hit_Energy = nullptr;
  vector<double> *Hit_X = nullptr;
	vector<double> *Hit_Y = nullptr;
	vector<double> *Hit_Z = nullptr;
	


	const int layerNu = 32;
	const int chipNu = 6;
	const int channelNu = 36;
	const int rowNu = 5;
	const int colNu = 42;
	const int doublelayerNu = 2;

  const int range_maximum = 12000;
  const int range_maximum_PS = 500;
  const double binWidth_PS = 0.1;



	TFile fileout(argv[1],"RECREATE");
  if(fileout.IsZombie()) return 1;
  // -1 marks a comparison which can contain both selections, never a SingleEnergy input.
  TParameter<int>("hl_tail_excluded", compareTailSelections ? -1 : int(excludeTailEvents)).Write();
  for (int ds = 0; ds < Ndatasim; ++ds)
    TParameter<int>(Form("hl_tail_excluded_sample_%d", ds), sampleTailSelection[ds]).Write();
  TNamed("resolution_value_exclusions", "data 200 GeV and missing/invalid energy fits: summary only; excluded from resolution points and fits").Write();
  std::ostringstream skippedPoints;
  skippedPoints << "sample\tenergy_GeV\treason\tinput\n";
  fileout.mkdir("simulation");
  fileout.mkdir("data");
	// gain_histo->Write();


	// dataを入れるもの
  TH1F* energy_deposition[rawfilenum][Ndatasim];
  TF1 *fit_gaus[rawfilenum][Ndatasim];
  TH2F* hitmap[rawfilenum][layerNu][Ndatasim];
  TH1F* number_of_hits[rawfilenum][Ndatasim];
  TF1 *fit_gaus_nhit[rawfilenum][Ndatasim];
  TH2F* hit_vs_e[rawfilenum][Ndatasim];
  TH2F* layer_vs_edep[rawfilenum][Ndatasim];

  TH1F* energy_deposition_bestChannels[rawfilenum][Ndatasim];
  TH2F* hitmap_bestChannels[rawfilenum][layerNu][Ndatasim];
  TH1F* number_of_hits_bestChannels[rawfilenum][Ndatasim];
  TH2F* hit_vs_e_bestChannels[rawfilenum][Ndatasim];
  TH2F* layer_vs_edep_bestChannels[rawfilenum][Ndatasim];

  TH1F* hit_per_layer[rawfilenum][layerNu][Ndatasim];
  TH1F* hit_per_layer_bestChannels[rawfilenum][layerNu][Ndatasim];
  TH1F* edep_per_layer[rawfilenum][layerNu][Ndatasim];
  TH1F* edep_per_layer_bestChannels[rawfilenum][layerNu][Ndatasim];

  TH2F* cog[rawfilenum][layerNu][Ndatasim];
  TH1F* shower_radiusRMS[rawfilenum][Ndatasim];
  TH1F* shower_radius90[rawfilenum][Ndatasim];
  TH2F* layer_vs_rRMS[rawfilenum][Ndatasim];
  TH2F* layer_vs_r90[rawfilenum][Ndatasim];
  TH1F* edep_1hit[rawfilenum][2][Ndatasim];
  TH1F* edep_1hit_allRagne[rawfilenum][2][Ndatasim];
  // TH2F* edep_vs_rRMS[rawfilenum];
  // TH2F* edep_vs_r90[rawfilenum];

  
  
	// 保存形式
  TGraphErrors *Eres[Ndatasim];
  for(int ds=0;ds<Ndatasim;ds++){
    Eres[ds] = new TGraphErrors();
    Eres[ds]->SetTitle("Energy Resolution");
    // Eres[ds]->SetTitle("Energy Resolution (all channels)");
    Eres[ds]->GetXaxis()->SetTitle("Beam Energy [GeV]");
    Eres[ds]->GetYaxis()->SetTitle("Detected Energy Resolution sigma(E)/E");
  }
  


	cout << "made save TTree" << endl;









  string dirNames[2] = {"beforeEventCut", "afterEventCut"};
  // string DataSim[2] = {"data", "simulation"};
  string histoDrawOptions[Ndatasim];
  string graphDrawOptions[Ndatasim];
  // Color_t histo_colors[2] = { kBlack  , kAzure - 9 };
  // Color_t fit_colors[2]   = { kRed + 1, kBlue + 1  };
  for(int ds=0;ds<Ndatasim;ds++){
    if(ds==0){
      histoDrawOptions[ds] = "HIST";
      graphDrawOptions[ds] = "AP";
    } else {
      histoDrawOptions[ds] = "HIST same";
      graphDrawOptions[ds] = "P";
    }
  }


  nameStrings drawSettings[Ndatasim];
  map<string,int> conditionIndices;
  for(int ds=0;ds<Ndatasim;ds++){      // cout << filenames[ds][ienergy].second << endl;
    if(customLabels){
      drawSettings[ds].label = labels[ds];
      drawSettings[ds].sampleIndex = ds;
      const string firstPath = argv[filenames[ds][0].second];
      int cog;
      if(ReadCoG(firstPath, cog)){
        for(const auto& input : filenames[ds]){
          int otherCoG;
          if(!ReadCoG(argv[input.second], otherCoG) || otherCoG != cog)
            throw invalid_argument("CoG selection changes across energies in sample " + to_string(ds+1));
        }
        drawSettings[ds].cog_range = cog;
        drawSettings[ds].cutIdx = CoGIndex(cog);
        auto conditionPath = std::filesystem::path(firstPath).parent_path();
        if(conditionPath.filename() == to_string(cog)+"mm") conditionPath = conditionPath.parent_path();
        // Use the configured path, not its symlink target: separate conditions
        // may legitimately refer to identical input files in a closure test.
        const string condition = conditionPath.lexically_normal().string();
        auto group = conditionIndices.emplace(condition, int(conditionIndices.size()));
        drawSettings[ds].conditionIndex = group.first->second;
      }
    } else {
      try {
        drawSettings[ds] = find_name_of_file(argv[filenames[ds][0].second]);
      } catch(const exception& error){
        cerr << "Cannot infer legacy sample settings: " << error.what() << "; use --labels for arbitrary samples" << endl;
        return 1;
      }
    }
  }




	// data をとってきてる
  for(int ienergy=0; ienergy<rawfilenum; ienergy++){
    if(filenames[0][ienergy].first != filenames[1][ienergy].first){
      cout << "wrong in energy sort !!" << endl;
      return 1;
    }
    double _energy = filenames[0][ienergy].first;
    // if(rawfilenum>1) cout << _energy << " GeV" << endl;
    fileout.cd();
    fileout.mkdir(Form("%dGeV", (int)_energy));
    fileout.cd(Form("%dGeV", (int)_energy));


    TFile *filein[Ndatasim];
    TCanvas* C_e_summary = new TCanvas(Form("Edep_%gGeV_summary",_energy), Form("%g GeV",_energy), 2560,1440); 
    C_e_summary->SetCanvasSize(2560, 1440); // Fix drawable/PNG size independently of window borders.
    C_e_summary->cd();
    C_e_summary->Divide(4,2);
    TCanvas* C_edeps = new TCanvas(Form("edeps_%gGeV",_energy), Form("%g GeV",_energy), 2560,1440); 
    C_edeps->SetCanvasSize(2560, 1440); // Fix drawable/PNG size independently of window borders.
    C_edeps->cd();
    C_edeps->Divide(6,5);
    TCanvas* C_nhits = new TCanvas(Form("nhits_%gGeV",_energy), Form("%g GeV",_energy), 2560,1440); 
    C_nhits->SetCanvasSize(2560, 1440); // Fix drawable/PNG size independently of window borders.
    C_nhits->cd();
    C_nhits->Divide(6,5);

    // data (0) or simulation (1)
    for(int ds=0;ds<Ndatasim;ds++){
      bool summaryOnly = SummaryOnlyData200(_energy, argv[filenames[ds][ienergy].second]);
      filein[ds] = new TFile(argv[filenames[ds][ienergy].second]);
      if(filein[ds]->IsZombie()){
        cerr << "Cannot read " << filein[ds]->GetName() << endl;
        return 1;
      }
      vector<string> histogramNames = {Form("edep_%dGeV", int(_energy)),
                                      Form("nhits_%dGeV", int(_energy)),
                                      "edep_1hit_10um", "edep_1hit_15um"};
      for(int layer=0; layer<30; ++layer){
        histogramNames.push_back(Form("edep_%dGeV_layer%d", int(_energy), layer));
        histogramNames.push_back(Form("nhits_%dGeV_layer%d", int(_energy), layer));
      }
      for(const string& name : histogramNames){
        const string key = dirNames[0] + "/" + name;
        if(!dynamic_cast<TH1F*>(filein[ds]->Get(key.c_str()))){
          cerr << "Missing TH1F " << key << " in " << filein[ds]->GetName() << endl;
          return 1;
        }
      }
      auto* energyFit = dynamic_cast<TF1*>(filein[ds]->Get((dirNames[0]+"/fit_gaus").c_str()));
      auto* hitFit = dynamic_cast<TF1*>(filein[ds]->Get((dirNames[0]+"/fit_gaus_nhit").c_str()));
      std::string skipReason;
      if (summaryOnly) skipReason = "data 200 GeV temporarily excluded";
      else if (!UsableComparisonFit(energyFit, true)) {
        summaryOnly = true;
        skipReason = "missing or invalid energy fit";
        if (energyFit && energyFit->GetNpar() >= 3)
          skipReason += ": mean="+std::to_string(energyFit->GetParameter(1))+", sigma="+std::to_string(energyFit->GetParameter(2));
      }
      if (summaryOnly) {
        cerr << "Skipping resolution value; keeping summary: " << filein[ds]->GetName() << "; " << skipReason << endl;
        skippedPoints << ds << "\t" << _energy << "\t" << skipReason << "\t" << filein[ds]->GetName() << "\n";
      }
      filein[ds]->cd();

      // cout << Form("%s/edep_%dGeV",dirNames[0].c_str(),(int)_energy) << endl;
      
      C_e_summary->cd();

      C_e_summary->cd(1);
      gStyle->SetOptStat(0);
      gStyle->SetOptFit(0);
      energy_deposition[ienergy][ds] = (TH1F*)filein[ds]->Get(Form("%s/edep_%dGeV",dirNames[0].c_str(),(int)_energy));
      ApplySampleStyle(energy_deposition[ienergy][ds], drawSettings[ds], 2);
      if (summaryOnly) {
        // Do not use an invalid fit for rebinning, display limits or values.
        energy_deposition[ienergy][ds]->GetXaxis()->SetRange(0, 0);
      } else {
        fit_gaus[ienergy][ds] = (TF1*)filein[ds]->Get(Form("%s/fit_gaus",dirNames[0].c_str()));
        auto* fit = fit_gaus[ienergy][ds];
        int rebinFactor = CalculateRebinFactor(energy_deposition[ienergy][ds], fit->GetParameter(2));
        energy_deposition[ienergy][ds]->Rebin(rebinFactor);
        fit->SetParameter(0, fit->GetParameter(0) * rebinFactor);
        fit->SetNpx(1000);
        energy_deposition[ienergy][ds]->GetXaxis()->SetRangeUser(fit->GetParameter(1)-10*fit->GetParameter(2),fit->GetParameter(1)+10*fit->GetParameter(2));
        ApplySampleStyle(fit, drawSettings[ds], 1, true);
        double mean = fit->GetParameter(1), mean_error = fit->GetParError(1);
        double sigma = fit->GetParameter(2), sigma_error = fit->GetParError(2);
        double res_error = sqrt(pow(sigma_error/mean,2) + pow(sigma*mean_error/mean/mean,2));
        // Append so omitting 200 GeV does not introduce a dummy (0,0) point.
        const int point = Eres[ds]->GetN();
        Eres[ds]->SetPoint(point, _energy, sigma/mean);
        Eres[ds]->SetPointError(point, 0, res_error);
      }
      energy_deposition[ienergy][ds]->Draw(histoDrawOptions[ds].c_str());

      C_e_summary->cd(2);
      gStyle->SetOptStat(0);
      gStyle->SetOptFit(0);
      number_of_hits[ienergy][ds] = (TH1F*)filein[ds]->Get(Form("%s/nhits_%dGeV",dirNames[0].c_str(),(int)_energy));
      ApplySampleStyle(number_of_hits[ienergy][ds], drawSettings[ds], 2);
      // number_of_hits[ienergy][ds]->SetLineColor(histo_colors[ds]);
      fit_gaus_nhit[ienergy][ds] = (TF1*)filein[ds]->Get(Form("%s/fit_gaus_nhit",dirNames[0].c_str()));
      // fitFunc = number_of_hits[ienergy][ds]->GetFunction("gaussian");
      if (summaryOnly || !UsableComparisonFit(hitFit)) number_of_hits[ienergy][ds]->GetXaxis()->SetRange(0, 0);
      if(ds==0 && !summaryOnly && UsableComparisonFit(hitFit)) number_of_hits[ienergy][ds]->GetXaxis()->SetRangeUser(fit_gaus_nhit[ienergy][ds]->GetParameter(1)-10*fit_gaus_nhit[ienergy][ds]->GetParameter(2),fit_gaus_nhit[ienergy][ds]->GetParameter(1)+10*fit_gaus_nhit[ienergy][ds]->GetParameter(2));
      number_of_hits[ienergy][ds]->Draw(histoDrawOptions[ds].c_str());
      
      // C_e_summary->cd(4);
      // gPad->SetLogz(1);
      // layer_vs_edep[ienergy]->Draw("colz");
      // layer_vs_edep[ienergy]->Write(Form("layer_vs_edep_%dGeV", (int)energy[ienergy]));

      int rebinFactor_1hit = 20;

      C_e_summary->cd(3);
      edep_1hit[ienergy][0][ds] = (TH1F*)filein[ds]->Get(Form("%s/edep_1hit_10um",dirNames[0].c_str()));
      edep_1hit[ienergy][0][ds]->Rebin(rebinFactor_1hit);
      ApplySampleStyle(edep_1hit[ienergy][0][ds], drawSettings[ds], 1);
      // edep_1hit[ienergy][0][ds]->SetLineColor(histo_colors[ds]);
      edep_1hit[ienergy][0][ds]->GetXaxis()->SetRangeUser(0,2);
      edep_1hit[ienergy][0][ds]->GetYaxis()->SetTitle("[a.u.]");
      edep_1hit[ienergy][0][ds]->Scale(1./edep_1hit[ienergy][0][ds]->Integral());
      edep_1hit[ienergy][0][ds]->Draw(histoDrawOptions[ds].c_str());
      C_e_summary->cd(4);
      edep_1hit[ienergy][1][ds] = (TH1F*)filein[ds]->Get(Form("%s/edep_1hit_15um",dirNames[0].c_str()));
      edep_1hit[ienergy][1][ds]->Rebin(rebinFactor_1hit);
      ApplySampleStyle(edep_1hit[ienergy][1][ds], drawSettings[ds], 1);
      // edep_1hit[ienergy][1][ds]->SetLineColor(histo_colors[ds]);
      edep_1hit[ienergy][1][ds]->GetXaxis()->SetRangeUser(0,2);
      edep_1hit[ienergy][1][ds]->GetYaxis()->SetTitle("[a.u.]");
      edep_1hit[ienergy][1][ds]->Scale(1./edep_1hit[ienergy][1][ds]->Integral());
      edep_1hit[ienergy][1][ds]->Draw(histoDrawOptions[ds].c_str());

      C_e_summary->cd(7);
      edep_1hit_allRagne[ienergy][0][ds] = (TH1F*)filein[ds]->Get(Form("%s/edep_1hit_10um",dirNames[0].c_str()));
      edep_1hit_allRagne[ienergy][0][ds]->SetTitle(Form("%g GeV Edep of 1 channel all range (10 um)",_energy));
      edep_1hit_allRagne[ienergy][0][ds]->Rebin(rebinFactor_1hit);
      ApplySampleStyle(edep_1hit_allRagne[ienergy][0][ds], drawSettings[ds], 1);
      // edep_1hit_allRagne[ienergy][0][ds]->SetLineColor(histo_colors[ds]);
      edep_1hit_allRagne[ienergy][0][ds]->GetXaxis()->SetRangeUser(0,12);
      edep_1hit_allRagne[ienergy][0][ds]->GetYaxis()->SetTitle("[a.u.]");
      edep_1hit_allRagne[ienergy][0][ds]->Scale(1./edep_1hit_allRagne[ienergy][0][ds]->Integral());
      edep_1hit_allRagne[ienergy][0][ds]->Draw(histoDrawOptions[ds].c_str());
      C_e_summary->cd(8);
      edep_1hit_allRagne[ienergy][1][ds] = (TH1F*)filein[ds]->Get(Form("%s/edep_1hit_15um",dirNames[0].c_str()));
      edep_1hit_allRagne[ienergy][1][ds]->SetTitle(Form("%g GeV Edep of 1 channel all range (15 um)",_energy));
      edep_1hit_allRagne[ienergy][1][ds]->Rebin(rebinFactor_1hit);
      ApplySampleStyle(edep_1hit_allRagne[ienergy][1][ds], drawSettings[ds], 1);
      // edep_1hit_allRagne[ienergy][1][ds]->SetLineColor(histo_colors[ds]);
      edep_1hit_allRagne[ienergy][1][ds]->GetXaxis()->SetRangeUser(0,12);
      edep_1hit_allRagne[ienergy][1][ds]->GetYaxis()->SetTitle("[a.u.]");
      edep_1hit_allRagne[ienergy][1][ds]->Scale(1./edep_1hit_allRagne[ienergy][1][ds]->Integral());
      edep_1hit_allRagne[ienergy][1][ds]->Draw(histoDrawOptions[ds].c_str());
      
      
      // 1 hit (10 15 um)
      // r shower
      // center og gravity
      
      
      



      // edep per layer
      C_edeps->cd();
      for (int i_layer = 0; i_layer < layerNu; ++i_layer) {
        if(i_layer>=30) continue;
        C_edeps->cd(i_layer+1);
        edep_per_layer[ienergy][i_layer][ds] = (TH1F*)filein[ds]->Get(Form("%s/edep_%dGeV_layer%d",dirNames[0].c_str(),(int)_energy,i_layer));
        edep_per_layer[ienergy][i_layer][ds]->Rebin(rebinFactor_1hit);
        ApplySampleStyle(edep_per_layer[ienergy][i_layer][ds], drawSettings[ds], 1);
        // edep_per_layer[ienergy][i_layer][ds]->SetLineColor(histo_colors[ds]);
        edep_per_layer[ienergy][i_layer][ds]->GetYaxis()->SetTitle("[a.u.]");
        edep_per_layer[ienergy][i_layer][ds]->Scale(1./edep_per_layer[ienergy][i_layer][ds]->Integral());
        gPad->SetLogy(1);
        edep_per_layer[ienergy][i_layer][ds]->Draw(histoDrawOptions[ds].c_str());
      }

      C_nhits->cd();
      for (int i_layer = 0; i_layer < layerNu; ++i_layer) {
        if(i_layer>=30) continue;
        C_nhits->cd(i_layer+1);
        hit_per_layer[ienergy][i_layer][ds] = (TH1F*)filein[ds]->Get(Form("%s/nhits_%dGeV_layer%d",dirNames[0].c_str(),(int)_energy,i_layer));
        ApplySampleStyle(hit_per_layer[ienergy][i_layer][ds], drawSettings[ds], 1);
        // hit_per_layer[ienergy][i_layer][ds]->SetLineColor(histo_colors[ds]);
        hit_per_layer[ienergy][i_layer][ds]->GetYaxis()->SetTitle("[a.u.]");
        hit_per_layer[ienergy][i_layer][ds]->Scale(1./hit_per_layer[ienergy][i_layer][ds]->Integral());
        gPad->SetLogy(1);
        hit_per_layer[ienergy][i_layer][ds]->Draw(histoDrawOptions[ds].c_str());
      }
    }

    // Overlay legends at the right of the full-width distribution panels.
    auto distributionLegend = [](){
      auto* legend=CreateNiceLegend(.62,.40,.89,.89,1);
      legend->SetMargin(.30); legend->SetTextSize(0);
      legend->SetEntrySeparation(.2);
      return legend;
    };
    TLegend *legHisto = distributionLegend();
    TLegend *legHits = distributionLegend();
    double max_height_edep=0, max_height_nhit=0;
    for(int ds=0;ds<Ndatasim;ds++){

      legHisto->AddEntry(energy_deposition[ienergy][ds], SampleCaption(drawSettings[ds]).c_str(), "l");
      legHits->AddEntry(number_of_hits[ienergy][ds], SampleCaption(drawSettings[ds]).c_str(), "l");
      if(max_height_edep < energy_deposition[ienergy][ds]->GetMaximum()) max_height_edep = energy_deposition[ienergy][ds]->GetMaximum();
      if(max_height_nhit < number_of_hits[ienergy][ds]->GetMaximum()) max_height_nhit = number_of_hits[ienergy][ds]->GetMaximum();
    }


    fileout.cd();
    C_e_summary->cd();
    C_e_summary->cd(1);
    energy_deposition[ienergy][0]->SetMaximum(max_height_edep * 1.15);
    legHisto->Draw("same");
    gPad->Modified();
    gPad->Update();
    C_e_summary->cd(2);
    number_of_hits[ienergy][0]->SetMaximum(max_height_nhit * 1.15);
    legHits->Draw("same");
    gPad->Modified();
    gPad->Update();
    C_e_summary->Write();
    C_e_summary->SaveAs(Form("%s/summary_%gGeV.png",argv[argc-1],_energy));

    C_edeps->Write();
    C_edeps->SaveAs(Form("%s/%gGeV_edeps.png",argv[argc-1],_energy));

    C_nhits->Write();
    C_nhits->SaveAs(Form("%s/%gGeV_nhits.png",argv[argc-1],_energy));


    if(!skipChannelPlots && !SaveChannelEnergyComparisons(filein, Ndatasim, drawSettings, _energy, fileout, argv[argc-1])) return 1;

    for(int ds=0;ds<Ndatasim;ds++){
      delete filein[ds];
    }
	}

  



  fileout.cd();
  // irawfilenum += energy_files[ienergy];

  cout << "fitting histograms ... " << endl;

  



  bool enable_reject = true;
  const double resolutionMaximum = 0.3;
  const double energyMaximum = 130.;

  auto FitFuncResolution = [&enable_reject](double *x, double *p) {
    // 25〜35 または 75〜85 の範囲に入った場合はフィット点から除外
    if (enable_reject && ( (x[0] > 25.0 && x[0] < 35.0) || (x[0] > 75.0 && x[0] < 85.0) )) {
        TF1::RejectPoint();
        return 0.0; // 除外されるため戻り値は何でもよい
    }
    // それ以外の範囲の元の関数: sqrt(p[0]^2/x + p[1]^2)
    // return sqrt((p[0]*p[0]) / x[0] + (p[1]*p[1]));
    return sqrt((p[0]*p[0]) / x[0] + (p[1]*p[1]));
  };

  TCanvas *resolution_summary = new TCanvas("summary_resolution", "Resolution summary", 2560,1440);
  resolution_summary->SetCanvasSize(2560, 1440); // Fix drawable/PNG size independently of window borders.
  resolution_summary->Divide(2,2);

  TCanvas *resolution_plots = new TCanvas("resolution_plots", "resolution_plots", 2560,1440); 
  resolution_plots->SetCanvasSize(2560, 1440); // Fix drawable/PNG size independently of window borders.
  if(!customLabels) resolution_plots->Divide(2,2);
  
  TLegend *legend_resolution = customLabels ? CreateSampleLegend(Ndatasim) : CreateNiceLegend(0.3, 0.4, 0.9, 0.85, 2);
  if(customLabels && Ndatasim >= 6){
    // Keep eight fit captions outside the data area, including in log views.
    resolution_plots->SetRightMargin(.46);
    legend_resolution->SetX1(.56); legend_resolution->SetX2(.99);
    legend_resolution->SetY1(.20); legend_resolution->SetY2(.90);
  }
  TF1 *res_func_low[Ndatasim];
  resolution_plots->cd();
  resolution_plots->cd(customLabels ? 0 : 1);
  gStyle->SetOptStat(0);
  gStyle->SetOptFit(0);
  resolution_plots->SetGrid();
  for(int ds=0;ds<Ndatasim;ds++){
    res_func_low[ds] = new TF1(Form("res_func_low_%d",ds),FitFuncResolution,1,300, 2);
    ApplySampleStyle(res_func_low[ds], drawSettings[ds], 1, true);
    // res_func_low[ds]->SetLineColor(fit_colors[ds]);
    res_func_low[ds]->SetParameter(0,0.2);
    res_func_low[ds]->SetParameter(1,0);
    enable_reject = true;
    Eres[ds]->Fit(Form("res_func_low_%d",ds), "","", 0.1,130);
    res_func_low[ds]->SetRange(0.1, 300.0);
    enable_reject = false;
    Eres[ds]->SetMinimum(0);
    Eres[ds]->SetMaximum(resolutionMaximum);
    // Eres[ds]->SetMarkerStyle(4);
    // Eres[ds]->SetMarkerColor(histo_colors[ds]);
    // Eres[ds]->SetLineColor(histo_colors[ds]);
    ApplySampleStyle(Eres[ds], drawSettings[ds], 1);
    Eres[ds]->SetMarkerSize(3.0);
    Eres[ds]->Draw(graphDrawOptions[ds].c_str());
    Eres[ds]->GetXaxis()->SetRangeUser(0.0, energyMaximum);
    res_func_low[ds]->Draw("same");

    string sampleCaption = SampleCaption(drawSettings[ds]);
    legend_resolution->AddEntry(Eres[ds], Form("%s #frac{%.3f}{#sqrt{E}} #oplus %.3f", sampleCaption.c_str(), abs(res_func_low[ds]->GetParameter(0)), abs(res_func_low[ds]->GetParameter(1))) , "lp");
  }
  gPad->Modified();
  gPad->Update();
  legend_resolution->Draw("same");

  if(!customLabels){
  resolution_plots->cd(3);
  gStyle->SetOptStat(0);
  gStyle->SetOptFit(0);
  resolution_plots->SetGrid();
  TLegend *legResData = CreateNiceLegend(0.3, 0.4, 0.9, 0.85, 1);
  for(int ds=0;ds<Ndatasim;ds++){
    if(!drawSettings[ds].isData) continue;
    Eres[ds]->Draw(graphDrawOptions[ds].c_str());
    Eres[ds]->GetXaxis()->SetRangeUser(0.0, 130);
    res_func_low[ds]->Draw("same");

    string sampleCaption = SampleCaption(drawSettings[ds]);
    legResData->AddEntry(Eres[ds], Form("%s #frac{%.3f}{#sqrt{E}} #oplus %.3f", sampleCaption.c_str(), abs(res_func_low[ds]->GetParameter(0)), abs(res_func_low[ds]->GetParameter(1))) , "lp");
  }
  gPad->Modified();
  gPad->Update();
  legResData->Draw("same");

  resolution_plots->cd(4);
  gStyle->SetOptStat(0);
  gStyle->SetOptFit(0);
  resolution_plots->SetGrid();
  TLegend *legResSim = CreateNiceLegend(0.3, 0.4, 0.9, 0.85, 1);
  int firstDrawing = 0;
  for(int ds=0;ds<Ndatasim;ds++){
    if(drawSettings[ds].isData) continue;
    if(firstDrawing==0) Eres[ds]->Draw("AP");
    else Eres[ds]->Draw(graphDrawOptions[ds].c_str());
    Eres[ds]->GetXaxis()->SetRangeUser(0.0, 130);
    res_func_low[ds]->Draw("same");

    string sampleCaption = SampleCaption(drawSettings[ds]);
    legResSim->AddEntry(Eres[ds], Form("%s #frac{%.3f}{#sqrt{E}} #oplus %.3f", sampleCaption.c_str(), abs(res_func_low[ds]->GetParameter(0)), abs(res_func_low[ds]->GetParameter(1))) , "lp");
    firstDrawing++;
  }
  gPad->Modified();
  gPad->Update();
  legResSim->Draw("same");

  }
  SaveResolutionViews(resolution_plots, fileout, argv[argc-1], "resolution", resolution_summary);






  // =================================================================
  // 【追加用】ノイズ項あり (a/sqrt(E) (+) b/E (+) c) のフィット＆描画処理
  // =================================================================
  
  bool enable_reject_noise = true;
  
  // 3 パラメータ（統計項, ノイズ項, 定数項）フィット関数
  auto FitFuncResolutionWithNoise = [&enable_reject_noise](double *x, double *p) {
      if (enable_reject_noise && ( (x[0] > 25.0 && x[0] < 35.0) || (x[0] > 75.0 && x[0] < 85.0) )) {
          TF1::RejectPoint();
          return 0.0;
      }
      double E = x[0];
      double term_stoch = (p[0] * p[0]) / E;         // (a / sqrt(E))^2
      double term_noise = (p[1] * p[1]) / (E * E);   // (b / E)^2
      double term_const = (p[2] * p[2]);             // c^2
      return sqrt(term_stoch + term_noise + term_const);
  };
  
  TCanvas *resolution_plots_noise = new TCanvas("resolution_plots_noise", "resolution_plots_noise", 2560, 1440); 
  resolution_plots_noise->SetCanvasSize(2560, 1440); // Fix drawable/PNG size independently of window borders.
  if(!customLabels) resolution_plots_noise->Divide(2, 2);
  
  TLegend *legend_resolution_noise = customLabels ? CreateSampleLegend(Ndatasim) : CreateNiceLegend(0.3, 0.4, 0.9, 0.85, 2);
  if(customLabels && Ndatasim >= 6){
    // Keep eight fit captions outside the data area, including in log views.
    resolution_plots_noise->SetRightMargin(.46);
    legend_resolution_noise->SetX1(.56); legend_resolution_noise->SetX2(.99);
    legend_resolution_noise->SetY1(.20); legend_resolution_noise->SetY2(.90);
  }
  TF1 *res_func_low_noise[Ndatasim];
  
  // --- 1. 全データ (Data + Sim) の描画 (cd(1)) ---
  resolution_plots_noise->cd(customLabels ? 0 : 1);
  gStyle->SetOptStat(0);
  gStyle->SetOptFit(0);
  resolution_plots_noise->SetGrid();
  
  for (int ds = 0; ds < Ndatasim; ds++) {
      res_func_low_noise[ds] = new TF1(Form("res_func_low_noise_%d", ds), FitFuncResolutionWithNoise, 0.1, 300, 3);
      ApplySampleStyle(res_func_low_noise[ds], drawSettings[ds], 1, true);
  
      // 初期値設定
      res_func_low_noise[ds]->SetParameter(0, 0.20); // 統計項 (a)
      res_func_low_noise[ds]->SetParameter(1, 0.05); // ノイズ項 (b)
      res_func_low_noise[ds]->SetParameter(2, 0.01); // 定数項 (c)
      
      // パラメータが負値に落ちるのを防ぐ制約
      res_func_low_noise[ds]->SetParLimits(0, 0.0, 2.0);
      res_func_low_noise[ds]->SetParLimits(1, 0.0, 5.0);
      res_func_low_noise[ds]->SetParLimits(2, 0.0, 1.0);
  
      enable_reject_noise = true;
      Eres[ds]->Fit(Form("res_func_low_noise_%d", ds), "", "", 0.1, 130);
      res_func_low_noise[ds]->SetRange(0.1, 300.0);
      enable_reject_noise = false;
  
      Eres[ds]->SetMinimum(0);
      Eres[ds]->SetMaximum(resolutionMaximum);
      ApplySampleStyle(Eres[ds], drawSettings[ds], 1);
      Eres[ds]->SetMarkerSize(3.0);
      Eres[ds]->Draw(graphDrawOptions[ds].c_str());
      Eres[ds]->GetXaxis()->SetRangeUser(0.0, energyMaximum);
      res_func_low_noise[ds]->Draw("same");

      string sampleCaption = SampleCaption(drawSettings[ds]);
  
      legend_resolution_noise->AddEntry(Eres[ds], Form("%s #frac{%.3f}{#sqrt{E}} #oplus #frac{%.3f}{E} #oplus %.3f", sampleCaption.c_str(), std::abs(res_func_low_noise[ds]->GetParameter(0)), std::abs(res_func_low_noise[ds]->GetParameter(1)), std::abs(res_func_low_noise[ds]->GetParameter(2))), "lp");
  }
  gPad->Modified();
  gPad->Update();
  legend_resolution_noise->Draw("same");
  
  // --- 2. Data のみの描画 (cd(3)) ---
  if(!customLabels){
  resolution_plots_noise->cd(3);
  gStyle->SetOptStat(0);
  gStyle->SetOptFit(0);
  resolution_plots_noise->SetGrid();
  TLegend *legResData_noise = CreateNiceLegend(0.3, 0.4, 0.9, 0.85, 1);
  
  for (int ds = 0; ds < Ndatasim; ds++) {
      if (!drawSettings[ds].isData) continue;
  
      Eres[ds]->Draw(graphDrawOptions[ds].c_str());
      Eres[ds]->GetXaxis()->SetRangeUser(0.0, 130);
      res_func_low_noise[ds]->Draw("same");

      string sampleCaption = SampleCaption(drawSettings[ds]);
  
      legResData_noise->AddEntry(Eres[ds], Form("%s #frac{%.3f}{#sqrt{E}} #oplus #frac{%.3f}{E} #oplus %.3f", sampleCaption.c_str(), std::abs(res_func_low_noise[ds]->GetParameter(0)), std::abs(res_func_low_noise[ds]->GetParameter(1)), std::abs(res_func_low_noise[ds]->GetParameter(2))), "lp");
  }
  gPad->Modified();
  gPad->Update();
  legResData_noise->Draw("same");
  
  // --- 3. Sim のみの描画 (cd(4)) ---
  resolution_plots_noise->cd(4);
  gStyle->SetOptStat(0);
  gStyle->SetOptFit(0);
  resolution_plots_noise->SetGrid();
  TLegend *legResSim_noise = CreateNiceLegend(0.3, 0.4, 0.9, 0.85, 1);
  int firstDrawing_noise = 0;
  
  for (int ds = 0; ds < Ndatasim; ds++) {
      if (drawSettings[ds].isData) continue;
  
      if (firstDrawing_noise == 0) Eres[ds]->Draw("AP");
      else Eres[ds]->Draw(graphDrawOptions[ds].c_str());
  
      Eres[ds]->GetXaxis()->SetRangeUser(0.0, 130);
      res_func_low_noise[ds]->Draw("same");

      string sampleCaption = SampleCaption(drawSettings[ds]);
  
      legResSim_noise->AddEntry(Eres[ds], Form("%s #frac{%.3f}{#sqrt{E}} #oplus #frac{%.3f}{E} #oplus %.3f", sampleCaption.c_str(), std::abs(res_func_low_noise[ds]->GetParameter(0)), std::abs(res_func_low_noise[ds]->GetParameter(1)), std::abs(res_func_low_noise[ds]->GetParameter(2))), "lp");
      firstDrawing_noise++;
  }
  gPad->Modified();
  gPad->Update();
  legResSim_noise->Draw("same");
  
  }
  // --- 4. 保存処理 ---
  SaveResolutionViews(resolution_plots_noise, fileout, argv[argc-1], "resolution_with_noise", resolution_summary);
  resolution_summary->cd();
  resolution_summary->Modified(); resolution_summary->Update();
  fileout.cd(); resolution_summary->Write("summary_resolution");
  resolution_summary->SaveAs(Form("%s/summary_resolution.png",argv[argc-1]));

  fileout.cd();
  TNamed("resolution_skipped_points", skippedPoints.str().c_str()).Write();
  TNamed("hl_tail_status", "complete").Write();
  return 0;
} catch (const std::exception& error) {
  std::cerr << error.what() << std::endl;
  return 1;
}
