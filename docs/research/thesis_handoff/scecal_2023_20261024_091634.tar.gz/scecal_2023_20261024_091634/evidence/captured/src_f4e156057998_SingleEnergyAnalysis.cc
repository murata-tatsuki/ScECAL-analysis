#include <iostream>
#include "HLTailSelection.hh"
#include <fstream>
#include "TROOT.h"
#include "TFile.h"
#include "TMath.h"
#include "TTree.h"
#include "TH1F.h"
#include "TH1S.h"
#include "TH2D.h"
#include "TH2S.h"
#include "TGraph.h"
#include "TGraphErrors.h"
#include "TF1.h"
#include "TLatex.h"
#include "TRandom.h"
#include "TRandom3.h"
#include <vector>
#include <string>
#include <algorithm>
#include <numeric>
#include <unordered_set>
#include <cmath>
#include "TLegend.h"
#include "TCanvas.h"
#include "weightedSSA.cpp"
#include "showerRaddius.cpp"
#include "langaus.C"				// langaus(chargeH, &fitFunc, &peakP, &peakPError);
// #include "../RawtoRoot/include/EBUdecode.h"
// #include "/megraid01/users/murata_t/scecal/ScECAL_CR/analyseCode/RawtoRoot/include/EBUdecode.h"
// #include "/megraid01/users/data_beamtest_SPS2022/analysis/ECAL_Analysis/include/EBUdecode.h"

using namespace std;


// エネルギー分布を求めるマクロ
// calibを使う

// 一つのビームエネルギーの解析用
// argvなどは複数エネルギーのものと同様になっていて、おそらく実際に複数エネルギーでも動くが、未検証

const bool cog_cut = true;


const unordered_set<int> bad_channels = {
  // bad channel の CellID をここに列挙
  1, 5, 13, 14, 33, 10004, 10022, 10030, 10031, 10032, 10033, 10034, 10035, 20029, 20033, 20034, 20035, 30003, 30005, 30009, 30013, 30015, 30023, 30025, 30027, 30028, 30030, 30031, 30032, 30033, 30034, 30035, 40001, 40002, 40003, 40005, 40007, 40009, 40011, 40013, 40015, 40017, 40024, 40025, 40026, 40027, 40028, 40029, 40030, 40032, 40034, 40035, 50003, 50004, 50009, 110010, 110022, 110025, 110030, 110031, 110032, 110033, 110034, 110035, 120029, 120030, 120032, 120035, 130024, 130028, 130030, 130032, 130033, 130034, 130035, 140009, 140015, 140034, 150003, 200001, 200007, 200034, 210024, 210030, 210031, 210032, 210033, 210034, 210035, 220030, 220033, 220034, 220035, 230001, 230012, 230021, 230024, 230025, 230027, 230028, 230030, 230031, 230032, 230033, 230034, 230035, 240018, 240026, 240027, 240029, 240030, 240034, 240035, 250000, 250009, 300008, 310010, 310012, 310028, 310032, 310034, 310035, 330001, 330027, 330029, 330031, 330033, 330034, 330035, 340022, 340032, 340034, 340035, 350005, 350009, 400013, 400014, 400016, 400018, 400020, 400022, 400024, 400025, 400028, 410004, 410005, 410006, 410007, 410009, 410010, 410011, 410012, 410017, 410019, 410020, 410021, 410022, 410023, 410025, 410026, 410027, 410028, 410029, 410030, 410031, 410032, 410033, 410034, 410035, 420000, 420002, 420014, 420020, 420025, 420027, 420033, 420034, 420035, 430017, 430021, 430023, 430024, 430025, 430026, 430027, 430028, 430029, 430030, 430031, 430032, 430033, 430034, 430035, 440000, 440001, 440003, 440005, 440006, 440012, 440016, 440019, 440021, 440023, 440024, 440025, 440026, 440027, 440028, 440029, 440030, 440031, 440032, 440033, 440034, 440035, 450001, 450002, 450003, 450008, 450015, 450017, 450018, 500001, 500002, 500003, 500022, 510011, 510013, 510017, 510023, 510025, 510026, 510027, 510028, 510029, 510030, 510031, 510032, 510033, 510034, 510035, 520003, 520028, 520030, 520033, 520034, 520035, 530001, 530003, 530007, 530009, 530011, 530012, 530013, 530017, 530020, 530021, 530022, 530023, 530024, 530025, 530026, 530027, 530028, 530029, 530030, 530031, 530032, 530033, 530034, 530035, 540011, 540032, 540033, 540034, 540035, 550009, 550010, 600000, 600016, 600025, 600027, 600029, 610021, 610022, 610025, 610029, 610030, 610031, 610032, 610033, 610034, 610035, 620000, 620033, 620034, 620035, 630001, 630003, 630005, 630006, 630007, 630009, 630011, 630013, 630014, 630015, 630016, 630017, 630018, 630019, 630020, 630021, 630022, 630023, 630024, 630025, 630026, 630027, 630028, 630029, 630030, 630031, 630032, 630033, 630034, 630035, 640000, 640001, 640002, 640003, 640005, 640007, 640008, 640010, 640011, 640012, 640013, 640015, 640017, 640018, 640019, 640021, 640022, 640023, 640024, 640025, 640026, 640027, 640028, 640029, 640030, 640032, 640033, 640034, 640035, 650007, 650008, 650009, 650010, 650017, 700000, 700001, 700035, 710001, 710003, 710007, 710009, 710013, 710017, 710019, 710021, 710022, 710023, 710025, 710027, 710028, 710031, 710032, 710034, 710035, 720028, 720029, 720030, 720031, 720032, 720033, 720034, 720035, 730003, 730005, 730006, 730007, 730008, 730009, 730011, 730012, 730014, 730015, 730016, 730017, 730019, 730021, 730022, 730023, 730024, 730025, 730026, 730027, 730029, 730030, 730031, 730032, 730033, 730034, 730035, 740001, 740002, 740007, 740008, 740012, 740027, 740034, 740035, 800001, 800002, 800003, 800004, 800005, 800006, 800016, 800020, 800022, 800030, 800032, 810001, 810003, 810007, 810009, 810010, 810011, 810012, 810013, 810014, 810015, 810017, 810021, 810023, 810025, 810026, 810027, 810028, 810029, 810030, 810031, 810032, 810033, 810034, 810035, 820016, 820017, 820033, 820034, 820035, 830000, 830002, 830003, 830004, 830005, 830007, 830008, 830009, 830011, 830012, 830013, 830015, 830016, 830017, 830018, 830019, 830021, 830023, 830024, 830025, 830027, 830028, 830029, 830030, 830031, 830032, 830033, 830034, 830035, 840000, 840001, 840002, 840003, 840004, 840005, 840007, 840008, 840010, 840012, 840014, 840019, 840020, 840023, 840024, 840025, 840026, 840027, 840028, 840029, 840030, 840031, 840032, 840033, 840034, 840035, 850001, 850002, 850003, 850008, 850009, 850019, 850021, 850022, 850024, 850025, 850027, 850029, 900002, 900015, 910005, 910007, 910021, 910029, 910033, 910034, 910035, 920015, 920016, 920017, 920030, 920033, 920035, 930009, 930015, 930016, 930017, 930018, 930019, 930023, 930024, 930025, 930026, 930027, 930028, 930029, 930030, 930031, 930032, 930033, 930034, 930035, 940001, 940003, 940005, 940029, 940030, 940031, 940033, 940034, 940035, 1000002, 1000004, 1000015, 1000018, 1000020, 1000024, 1000025, 1000026, 1000028, 1000029, 1000030, 1000032, 1000035, 1010001, 1010002, 1010003, 1010005, 1010007, 1010008, 1010012, 1010014, 1010015, 1010017, 1010018, 1010019, 1010020, 1010021, 1010022, 1010023, 1010024, 1010025, 1010027, 1010028, 1010029, 1010030, 1010031, 1010032, 1010033, 1010034, 1010035, 1020002, 1020015, 1020024, 1020032, 1020033, 1020034, 1020035, 1030001, 1030003, 1030004, 1030005, 1030006, 1030007, 1030008, 1030009, 1030010, 1030011, 1030012, 1030013, 1030015, 1030016, 1030017, 1030018, 1030019, 1030020, 1030021, 1030023, 1030024, 1030025, 1030026, 1030027, 1030028, 1030029, 1030030, 1030031, 1030032, 1030033, 1030034, 1030035, 1040000, 1040001, 1040002, 1040003, 1040004, 1040005, 1040006, 1040007, 1040009, 1040010, 1040011, 1040012, 1040013, 1040014, 1040015, 1040016, 1040018, 1040019, 1040021, 1040022, 1040023, 1040024, 1040025, 1040026, 1040027, 1040028, 1040029, 1040030, 1040032, 1040033, 1040034, 1040035, 1050005, 1050009, 1050013, 1100004, 1100005, 1100007, 1100011, 1100024, 1100032, 1110006, 1110014, 1110015, 1110022, 1110024, 1110025, 1110030, 1110031, 1110032, 1110033, 1110034, 1110035, 1120001, 1120015, 1120017, 1120029, 1130003, 1130004, 1130005, 1130007, 1130009, 1130011, 1130015, 1130021, 1130023, 1130025, 1130027, 1130028, 1130029, 1130030, 1130031, 1130032, 1130033, 1130034, 1130035, 1140000, 1140004, 1140007, 1140010, 1140022, 1140025, 1140030, 1140031, 1140032, 1140033, 1140034, 1140035, 1150010, 1150011, 1200003, 1200015, 1200016, 1200018, 1200026, 1210003, 1210007, 1210009, 1210013, 1210015, 1210017, 1210018, 1210019, 1210020, 1210021, 1210022, 1210023, 1210025, 1210027, 1210029, 1210030, 1210031, 1210032, 1210033, 1210034, 1210035, 1220002, 1220024, 1220026, 1220033, 1220034, 1220035, 1230001, 1230003, 1230005, 1230007, 1230015, 1230017, 1230019, 1230021, 1230022, 1230023, 1230025, 1230026, 1230027, 1230029, 1230030, 1230031, 1230032, 1230033, 1230034, 1230035, 1240000, 1240001, 1240002, 1240003, 1240005, 1240006, 1240008, 1240009, 1240010, 1240011, 1240013, 1240014, 1240015, 1240016, 1240017, 1240019, 1240021, 1240022, 1240023, 1240024, 1240025, 1240026, 1240027, 1240028, 1240029, 1240030, 1240032, 1240033, 1240034, 1240035, 1250001, 1250002, 1250006, 1250010, 1250013, 1300001, 1300002, 1300003, 1300004, 1300006, 1300007, 1300009, 1300012, 1300020, 1310004, 1310009, 1310017, 1310019, 1310025, 1310026, 1310027, 1310028, 1310030, 1310031, 1310033, 1310034, 1310035, 1320027, 1320028, 1320029, 1320030, 1320031, 1320032, 1320033, 1320034, 1320035, 1330011, 1330015, 1330017, 1330018, 1330019, 1330020, 1330021, 1330022, 1330023, 1330024, 1330025, 1330026, 1330027, 1330028, 1330029, 1330031, 1330032, 1330033, 1330034, 1330035, 1340007, 1340019, 1340023, 1340028, 1340030, 1340032, 1340033, 1340034, 1340035, 1350006, 1350008, 1350009, 1400005, 1400016, 1400018, 1400020, 1400022, 1400024, 1400026, 1400028, 1400030, 1400032, 1410001, 1410002, 1410004, 1410005, 1410006, 1410007, 1410009, 1410010, 1410013, 1410015, 1410018, 1410019, 1410020, 1410021, 1410022, 1410023, 1410025, 1410027, 1410028, 1410029, 1410030, 1410031, 1410032, 1410033, 1410034, 1410035, 1420000, 1420001, 1420002, 1420015, 1420016, 1420017, 1420031, 1420033, 1420034, 1420035, 1430000, 1430001, 1430003, 1430005, 1430008, 1430010, 1430011, 1430013, 1430015, 1430018, 1430019, 1430021, 1430022, 1430023, 1430025, 1430027, 1430028, 1430029, 1430030, 1430031, 1430032, 1430033, 1430034, 1430035, 1440001, 1440002, 1440003, 1440004, 1440005, 1440006, 1440007, 1440008, 1440009, 1440010, 1440011, 1440012, 1440013, 1440014, 1440015, 1440016, 1440017, 1440018, 1440019, 1440020, 1440021, 1440022, 1440023, 1440024, 1440025, 1440026, 1440027, 1440028, 1440029, 1440030, 1440031, 1440032, 1440033, 1440034, 1440035, 1450000, 1450001, 1450002, 1450004, 1450006, 1450007, 1450022, 1450024, 1450026, 1450027, 1450029, 1500003, 1500006, 1510001, 1510017, 1510029, 1510032, 1510033, 1510034, 1520031, 1520034, 1530000, 1530005, 1530021, 1530022, 1530023, 1530025, 1530027, 1530028, 1530029, 1530030, 1530031, 1530033, 1530034, 1530035, 1540001, 1540011, 1540027, 1540028, 1540032, 1540034, 1540035, 1550009, 1550025, 1600000, 1600012, 1600020, 1600026, 1600030, 1600031, 1600032, 1610000, 1610005, 1610009, 1610011, 1610013, 1610015, 1610017, 1610019, 1610021, 1610022, 1610025, 1610027, 1610029, 1610030, 1610031, 1610032, 1610033, 1610034, 1610035, 1620009, 1620012, 1620013, 1620014, 1620015, 1620016, 1620018, 1620019, 1620020, 1620021, 1620022, 1620024, 1620027, 1620028, 1620030, 1620033, 1620034, 1620035, 1630005, 1630007, 1630009, 1630011, 1630013, 1630015, 1630017, 1630019, 1630023, 1630024, 1630025, 1630026, 1630027, 1630029, 1630030, 1630031, 1630032, 1630033, 1630034, 1630035, 1640002, 1640005, 1640007, 1640009, 1640011, 1640013, 1640015, 1640017, 1640019, 1640021, 1640022, 1640023, 1640026, 1640027, 1640028, 1640029, 1640033, 1640034, 1650003, 1650009, 1650010, 1650011, 1650022, 1650026, 1650027, 1650028, 1650029, 1700001, 1700003, 1700006, 1710004, 1710005, 1710009, 1710013, 1710014, 1710015, 1710019, 1710022, 1710023, 1710025, 1710026, 1710027, 1710029, 1710031, 1710032, 1710033, 1710034, 1710035, 1720029, 1720030, 1720032, 1720033, 1720034, 1720035, 1730001, 1730005, 1730007, 1730009, 1730011, 1730013, 1730016, 1730017, 1730018, 1730020, 1730027, 1730031, 1730032, 1730033, 1730035, 1740000, 1740001, 1740006, 1740026, 1740034, 1750009, 1750010, 1750021, 1800016, 1800020, 1800022, 1800028, 1800029, 1800035, 1810011, 1810015, 1810017, 1810023, 1810025, 1810028, 1810029, 1810030, 1810031, 1810032, 1810033, 1810034, 1810035, 1820016, 1820026, 1820032, 1820033, 1820034, 1820035, 1830001, 1830003, 1830004, 1830005, 1830006, 1830007, 1830009, 1830010, 1830011, 1830012, 1830013, 1830014, 1830015, 1830017, 1830019, 1830020, 1830021, 1830022, 1830023, 1830024, 1830025, 1830027, 1830028, 1830029, 1830030, 1830031, 1830032, 1830033, 1830034, 1830035, 1840001, 1840002, 1840003, 1840004, 1840005, 1840007, 1840008, 1840009, 1840010, 1840011, 1840013, 1840014, 1840015, 1840016, 1840017, 1840018, 1840020, 1840021, 1840022, 1840023, 1840024, 1840025, 1840026, 1840027, 1840028, 1840029, 1840030, 1840032, 1840033, 1840034, 1840035, 1850000, 1850001, 1850003, 1850004, 1850006, 1850007, 1850009, 1850010, 1850024, 1850025, 1900000, 1900001, 1900004, 1900005, 1900006, 1900026, 1910003, 1910007, 1910009, 1910015, 1910017, 1910019, 1910021, 1910022, 1910023, 1910025, 1910026, 1910027, 1910029, 1910030, 1910031, 1910032, 1910033, 1910034, 1910035, 1920016, 1920025, 1920028, 1920029, 1920030, 1920031, 1920032, 1920034, 1920035, 1930009, 1930013, 1930016, 1930018, 1930020, 1930022, 1930023, 1930025, 1930027, 1930028, 1930029, 1930031, 1930032, 1930033, 1930035, 1940000, 1940003, 1940017, 1940026, 1940032, 1940033, 1940034, 1940035, 1950005, 1950009, 1950010, 1950013, 2000000, 2000018, 2000020, 2000022, 2000028, 2010001, 2010002, 2010006, 2010007, 2010008, 2010009, 2010010, 2010011, 2010013, 2010014, 2010015, 2010016, 2010017, 2010018, 2010019, 2010020, 2010021, 2010022, 2010023, 2010025, 2010026, 2010027, 2010028, 2010029, 2010030, 2010031, 2010032, 2010033, 2010034, 2010035, 2020006, 2020015, 2020017, 2020028, 2020029, 2020032, 2020033, 2020034, 2020035, 2030000, 2030001, 2030005, 2030006, 2030007, 2030013, 2030015, 2030017, 2030019, 2030023, 2030024, 2030025, 2030027, 2030029, 2030030, 2030031, 2030032, 2030033, 2030034, 2030035, 2040000, 2040001, 2040002, 2040003, 2040004, 2040007, 2040008, 2040010, 2040011, 2040015, 2040016, 2040017, 2040018, 2040019, 2040020, 2040021, 2040022, 2040023, 2040024, 2040025, 2040026, 2040027, 2040028, 2040029, 2040030, 2040031, 2040032, 2040033, 2040034, 2040035, 2050002, 2050006, 2050009, 2050010, 2050011, 2050012, 2050021, 2050023, 2050029, 2100000, 2100002, 2100003, 2100005, 2100006, 2100023, 2110019, 2110025, 2110027, 2110028, 2110032, 2110034, 2110035, 2120017, 2120031, 2120032, 2120033, 2120034, 2120035, 2130002, 2130007, 2130009, 2130010, 2130011, 2130013, 2130017, 2130019, 2130020, 2130021, 2130023, 2130024, 2130025, 2130026, 2130027, 2130029, 2130030, 2130031, 2130032, 2130033, 2130034, 2130035, 2140019, 2140026, 2140027, 2140030, 2140032, 2140033, 2140034, 2140035, 2150009, 2150010, 2150021, 2200020, 2200022, 2200024, 2210017, 2210019, 2210023, 2210025, 2210027, 2210028, 2210029, 2210030, 2210031, 2210032, 2210033, 2210034, 2210035, 2220000, 2220001, 2220033, 2220034, 2220035, 2230002, 2230007, 2230008, 2230011, 2230015, 2230017, 2230020, 2230023, 2230025, 2230027, 2230028, 2230030, 2230031, 2230032, 2230033, 2230034, 2230035, 2240000, 2240001, 2240002, 2240003, 2240005, 2240006, 2240007, 2240009, 2240011, 2240012, 2240013, 2240014, 2240015, 2240017, 2240018, 2240019, 2240020, 2240021, 2240022, 2240023, 2240024, 2240025, 2240026, 2240027, 2240028, 2240029, 2240030, 2240032, 2240034, 2240035, 2250007, 2250022, 2250026, 2250028, 2300000, 2300001, 2300003, 2300004, 2300006, 2300007, 2300013, 2300033, 2300034, 2310005, 2310007, 2310011, 2310013, 2310015, 2310019, 2310021, 2310023, 2310024, 2310025, 2310026, 2310027, 2310028, 2310029, 2310030, 2310031, 2310032, 2310033, 2310034, 2310035, 2320028, 2320029, 2320031, 2320032, 2320033, 2320034, 2330000, 2330001, 2330003, 2330005, 2330009, 2330010, 2330011, 2330012, 2330015, 2330016, 2330017, 2330018, 2330021, 2330022, 2330023, 2330024, 2330025, 2330026, 2330027, 2330028, 2330029, 2330031, 2330032, 2330033, 2330035, 2340027, 2340030, 2340031, 2340032, 2340033, 2340034, 2340035, 2350008, 2350009, 2350010, 2350021, 2400016, 2400020, 2400022, 2410005, 2410007, 2410010, 2410013, 2410019, 2410023, 2410025, 2410027, 2410029, 2410030, 2410031, 2410032, 2410033, 2410034, 2410035, 2420000, 2420011, 2420015, 2420017, 2420033, 2420034, 2420035, 2430000, 2430001, 2430002, 2430003, 2430005, 2430007, 2430009, 2430011, 2430013, 2430015, 2430017, 2430019, 2430020, 2430021, 2430022, 2430023, 2430024, 2430027, 2430028, 2430029, 2430030, 2430031, 2430032, 2430033, 2430034, 2430035, 2440000, 2440001, 2440002, 2440003, 2440005, 2440007, 2440009, 2440010, 2440011, 2440012, 2440013, 2440014, 2440015, 2440016, 2440017, 2440019, 2440020, 2440021, 2440022, 2440023, 2440024, 2440025, 2440026, 2440027, 2440028, 2440029, 2440030, 2440031, 2440032, 2440033, 2440035, 2450000, 2450001, 2450013, 2450022, 2450023, 2450028, 2450029, 2500000, 2500001, 2500002, 2500003, 2500004, 2500005, 2500006, 2500007, 2500013, 2500014, 2500015, 2500022, 2500034, 2500035, 2510004, 2510010, 2510015, 2510017, 2510019, 2510020, 2510021, 2510022, 2510023, 2510024, 2510025, 2510026, 2510027, 2510028, 2510029, 2510030, 2510031, 2510032, 2510033, 2510034, 2510035, 2520032, 2520033, 2520034, 2530001, 2530003, 2530005, 2530009, 2530011, 2530015, 2530016, 2530019, 2530020, 2530021, 2530022, 2530023, 2530025, 2530026, 2530027, 2530028, 2530029, 2530030, 2530031, 2530032, 2530033, 2530034, 2530035, 2540001, 2540003, 2540008, 2540010, 2540013, 2540014, 2540015, 2540024, 2540025, 2540027, 2540030, 2540031, 2540033, 2540034, 2540035, 2550008, 2550009, 2550015, 2550021, 2600001, 2600003, 2600005, 2600012, 2600018, 2600020, 2600022, 2600024, 2600026, 2600030, 2600032, 2610001, 2610003, 2610004, 2610005, 2610007, 2610011, 2610013, 2610014, 2610015, 2610017, 2610019, 2610020, 2610021, 2610022, 2610023, 2610024, 2610025, 2610027, 2610029, 2610030, 2610031, 2610032, 2610033, 2610034, 2610035, 2620001, 2620015, 2620017, 2620033, 2620034, 2620035, 2630001, 2630003, 2630005, 2630006, 2630007, 2630009, 2630011, 2630012, 2630013, 2630015, 2630017, 2630019, 2630021, 2630022, 2630023, 2630024, 2630025, 2630027, 2630028, 2630029, 2630030, 2630031, 2630032, 2630033, 2630034, 2630035, 2640000, 2640001, 2640002, 2640003, 2640005, 2640006, 2640007, 2640009, 2640010, 2640011, 2640013, 2640015, 2640016, 2640017, 2640019, 2640021, 2640022, 2640023, 2640024, 2640025, 2640026, 2640027, 2640028, 2640029, 2640030, 2640031, 2640032, 2640033, 2640034, 2640035, 2650006, 2650021, 2650023, 2650024, 2650027, 2650028, 2650029, 2700000, 2700002, 2700004, 2700009, 2700012, 2700030, 2700032, 2710000, 2710001, 2710002, 2710003, 2710007, 2710009, 2710013, 2710015, 2710016, 2710019, 2710021, 2710025, 2710026, 2710029, 2710030, 2710032, 2710033, 2710034, 2710035, 2720027, 2720032, 2720033, 2720035, 2730001, 2730005, 2730006, 2730007, 2730009, 2730011, 2730012, 2730013, 2730015, 2730016, 2730019, 2730022, 2730023, 2730025, 2730027, 2730028, 2730029, 2730031, 2730032, 2730033, 2730034, 2730035, 2740009, 2740013, 2740016, 2740030, 2740032, 2740033, 2740034, 2750009, 2750010, 2750011, 2750023, 2800005, 2800018, 2800021, 2800022, 2800032, 2810006, 2810013, 2810018, 2810025, 2810027, 2810028, 2810029, 2810030, 2810031, 2810032, 2810033, 2810034, 2810035, 2820006, 2820016, 2820017, 2820026, 2820033, 2820034, 2820035, 2830001, 2830003, 2830005, 2830007, 2830009, 2830010, 2830011, 2830013, 2830014, 2830015, 2830016, 2830017, 2830019, 2830021, 2830023, 2830025, 2830027, 2830028, 2830029, 2830030, 2830031, 2830032, 2830033, 2830034, 2830035, 2840000, 2840001, 2840002, 2840003, 2840005, 2840013, 2840015, 2840016, 2840019, 2840021, 2840022, 2840023, 2840024, 2840025, 2840026, 2840027, 2840028, 2840029, 2840030, 2840032, 2840033, 2840034, 2840035, 2850009, 2850019, 2900000, 2900001, 2900007, 2910000, 2910007, 2910019, 2910021, 2910022, 2910023, 2910024, 2910027, 2910029, 2910031, 2910032, 2910033, 2910034, 2910035, 2920023, 2920032, 2920033, 2920034, 2920035, 2930016, 2930019, 2930022, 2930023, 2930024, 2930025, 2930026, 2930027, 2930028, 2930029, 2930030, 2930031, 2930032, 2930033, 2930034, 2930035, 2940015, 2940017, 2940022, 2940027, 2940032, 2940034, 2940035, 2950009, 2950012, 3000000, 3000001, 3000002, 3000003, 3000004, 3000005, 3000006, 3000007, 3000008, 3000009, 3000010, 3000011, 3000012, 3000013, 3000014, 3000015, 3000016, 3000017, 3000018, 3000019, 3000020, 3000021, 3000022, 3000023, 3000024, 3000025, 3000026, 3000027, 3000028, 3000029, 3000030, 3000031, 3000032, 3000033, 3000034, 3000035, 3010000, 3010001, 3010002, 3010003, 3010004, 3010005, 3010006, 3010007, 3010008, 3010009, 3010010, 3010011, 3010012, 3010013, 3010014, 3010015, 3010016, 3010017, 3010018, 3010019, 3010020, 3010021, 3010022, 3010023, 3010024, 3010025, 3010026, 3010027, 3010028, 3010029, 3010030, 3010031, 3010032, 3010033, 3010034, 3010035, 3020000, 3020001, 3020002, 3020003, 3020004, 3020005, 3020006, 3020007, 3020008, 3020009, 3020010, 3020011, 3020012, 3020013, 3020014, 3020015, 3020016, 3020017, 3020018, 3020019, 3020020, 3020021, 3020022, 3020023, 3020024, 3020025, 3020026, 3020027, 3020028, 3020029, 3020030, 3020031, 3020032, 3020033, 3020034, 3020035, 3030000, 3030001, 3030002, 3030003, 3030004, 3030005, 3030006, 3030007, 3030008, 3030009, 3030010, 3030011, 3030012, 3030013, 3030014, 3030015, 3030016, 3030017, 3030018, 3030019, 3030020, 3030021, 3030022, 3030023, 3030024, 3030025, 3030026, 3030027, 3030028, 3030029, 3030030, 3030031, 3030032, 3030033, 3030034, 3030035, 3040000, 3040001, 3040002, 3040003, 3040004, 3040005, 3040006, 3040007, 3040008, 3040009, 3040010, 3040011, 3040012, 3040013, 3040014, 3040015, 3040016, 3040017, 3040018, 3040019, 3040020, 3040021, 3040022, 3040023, 3040024, 3040025, 3040026, 3040027, 3040028, 3040029, 3040030, 3040031, 3040032, 3040033, 3040034, 3040035, 3050000, 3050001, 3050002, 3050003, 3050004, 3050005, 3050006, 3050007, 3050008, 3050009, 3050010, 3050011, 3050012, 3050013, 3050014, 3050015, 3050016, 3050017, 3050018, 3050019, 3050020, 3050021, 3050022, 3050023, 3050024, 3050025, 3050026, 3050027, 3050028, 3050029, 3100000, 3100001, 3100002, 3100003, 3100004, 3100005, 3100006, 3100007, 3100008, 3100009, 3100010, 3100011, 3100012, 3100013, 3100014, 3100015, 3100016, 3100017, 3100018, 3100019, 3100020, 3100021, 3100022, 3100023, 3100024, 3100025, 3100026, 3100027, 3100028, 3100029, 3100030, 3100031, 3100032, 3100033, 3100034, 3100035, 3110000, 3110001, 3110002, 3110003, 3110004, 3110005, 3110006, 3110007, 3110008, 3110009, 3110010, 3110011, 3110012, 3110013, 3110014, 3110015, 3110016, 3110017, 3110018, 3110019, 3110020, 3110021, 3110022, 3110023, 3110024, 3110025, 3110026, 3110027, 3110028, 3110029, 3110030, 3110031, 3110032, 3110033, 3110034, 3110035, 3120000, 3120001, 3120002, 3120003, 3120004, 3120005, 3120006, 3120007, 3120008, 3120009, 3120010, 3120011, 3120012, 3120013, 3120014, 3120015, 3120016, 3120017, 3120018, 3120019, 3120020, 3120021, 3120022, 3120023, 3120024, 3120025, 3120026, 3120027, 3120028, 3120029, 3120030, 3120031, 3120032, 3120033, 3120034, 3120035, 3130000, 3130001, 3130002, 3130003, 3130004, 3130005, 3130006, 3130007, 3130008, 3130009, 3130010, 3130011, 3130012, 3130013, 3130014, 3130015, 3130016, 3130017, 3130018, 3130019, 3130020, 3130021, 3130022, 3130023, 3130024, 3130025, 3130026, 3130027, 3130028, 3130029, 3130030, 3130031, 3130032, 3130033, 3130034, 3130035, 3140000, 3140001, 3140002, 3140003, 3140004, 3140005, 3140006, 3140007, 3140008, 3140009, 3140010, 3140011, 3140012, 3140013, 3140014, 3140015, 3140016, 3140017, 3140018, 3140019, 3140020, 3140021, 3140022, 3140023, 3140024, 3140025, 3140026, 3140027, 3140028, 3140029, 3140030, 3140031, 3140032, 3140033, 3140034, 3140035, 3150000, 3150001, 3150002, 3150003, 3150004, 3150005, 3150006, 3150007, 3150008, 3150009, 3150010, 3150011, 3150012, 3150013, 3150014, 3150015, 3150016, 3150017, 3150018, 3150019, 3150020, 3150021, 3150022, 3150023, 3150024, 3150025, 3150026, 3150027, 3150028, 3150029
};

bool cog_position_check(double x, double y, double range=200){
  return !cog_cut || (abs(x)<range && abs(y)<range);
}

int sipmtypes(int layer){
  // layer 4~27 は10 umのもの    return 0
  // それ以外のlayerは15 umのもの return 1
    // layer 0~3, 28~31
  return ((layer < 4) || (layer >27)) ? 1 : 0;
}

#include <vector>
#include <cmath>
#include <iostream>

/*
double CalculateShowerRadiusRMS(const vector<double>& x, const vector<double>& y, const vector<double>& energy){
  // データのサイズチェック
  if (x.empty() || x.size() != y.size() || x.size() != energy.size()) {
    std::cerr << "Warning: Input vector sizes mismatch or empty." << std::endl;
    return -1.0; 
  }

  double E_tot = 0.0;
  double sum_X = 0.0;
  double sum_Y = 0.0;
  size_t n_hits = x.size();

  // 1. 総エネルギーとエネルギー重心(Center of Gravity)の計算
  for (size_t i = 0; i < n_hits; ++i) {
    if (energy[i] <= 0) continue; // ノイズ等による負のエネルギーや0を排除
    E_tot += energy[i];
    sum_X += x[i] * energy[i];
    sum_Y += y[i] * energy[i];
  }

  // 総エネルギーがゼロ（ヒットなし）の場合はエラーを返す
  if (E_tot <= 0.0) return 0.0;

  double X_CoG = sum_X / E_tot;
  double Y_CoG = sum_Y / E_tot;

  // 2. 各軸の分散(Variance)の計算
  double sum_var_X = 0.0;
  double sum_var_Y = 0.0;

  for (size_t i = 0; i < n_hits; ++i) {
    if (energy[i] <= 0) continue;
    sum_var_X += energy[i] * std::pow(x[i] - X_CoG, 2);
    sum_var_Y += energy[i] * std::pow(y[i] - Y_CoG, 2);
  }

  double var_x = sum_var_X / E_tot;
  double var_y = sum_var_Y / E_tot;

  // 3. RMS半径 (R_RMS = sqrt(sigma_x^2 + sigma_y^2)) の計算
  double R_num_RMS = std::sqrt(var_x + var_y);

  // 4. 2次元ガウシアンを仮定してR90へ換算 (R90 ≒ 1.518 * R_RMS)
  double R90 = 1.518 * R_num_RMS;

  return R90;
}
*/

bool eventCutConditions(double edep_event, double nhit_event, double edep_mean, double edep_sigma, double nhit_mean, double nhit_sigma){
  double edep_square = pow((edep_event-edep_mean) / (3*edep_sigma), 2);
  double nhit_square = pow((nhit_event-nhit_mean) / (3*nhit_sigma), 2);
  return (edep_square + nhit_square) > 1;
}

int main(int argc, char* argv[]) try
{
  if (argc < 3 || std::string(argv[1]) == "--help") {
    cout << "Usage: SingleEnergyAnalysis output.root Nenergy E1...En E1Nfiles...EnNfiles input.root... cog_range only_best figure_path [--exclude-tail-events|--keep-tail-events] [--tail-results DIR]" << endl;
    cout << "Default: exclude tail-rich events (>=3 distinct low-tail channels). DIR contains <energy>GeV/tail_study.root and inputs/." << endl;
    return argc == 2 && std::string(argv[1]) == "--help" ? 0 : 1;
  }
  const int nEnergy = std::stoi(argv[2]);
  hl_tail::require(nEnergy > 0 && 3LL + 2LL*nEnergy <= argc, "invalid energy count");
  long long nFiles = 0;
  for (int i = 0; i < nEnergy; ++i) {
    const int count = std::stoi(argv[3+nEnergy+i]);
    hl_tail::require(count > 0, "file count must be positive");
    nFiles += count;
  }
  const long long positionalArgc = 6LL + 2LL*nEnergy + nFiles;
  hl_tail::require(positionalArgc <= argc, "input file count does not match arguments");
  bool excludeTailEvents = true;
  bool tailModeSpecified = false;
  std::filesystem::path tailResults = std::filesystem::canonical(argv[0]).parent_path() /
      "../result/channel_response/hg_lg_tail/threshold/e_ssa";
  for (int i = int(positionalArgc); i < argc; ++i) {
    const std::string option = argv[i];
    if (option == "--exclude-tail-events" || option == "--keep-tail-events") {
      hl_tail::require(!tailModeSpecified, "specify one tail selection option");
      excludeTailEvents = option == "--exclude-tail-events";
      tailModeSpecified = true;
    } else if (option == "--tail-results") {
      hl_tail::require(i + 1 < argc, "--tail-results requires a directory");
      tailResults = argv[++i];
    } else {
      throw std::runtime_error("Unknown option: " + option);
    }
  }
  argc = int(positionalArgc);
  gROOT->SetBatch(kTRUE);

    //cout << argv[1] << endl;
	cout << "=====>  " << argv[1] << endl;

  int Nenegry = atoi(argv[2]);
  double energy[Nenegry];
  int energy_files[Nenegry];
  for(int i=0;i<Nenegry;i++){
    energy[i] = atoi(argv[3+i]);
    if(energy[i]<1) energy[i] = 0.5;
    energy_files[i] = atoi(argv[3+Nenegry+i]);
  }
  
  
	int rawfilenum = argc - 2 - 2*Nenegry - 3;
  int irawfilenum = 3 + 2*Nenegry;
  int cog_range = atoi(argv[argc-3]);
  int bool_only_best = atoi(argv[argc-2]);
  string bestChannel = bool_only_best == 1 ? "_bestChannels" : "";


  // Validate complete event coverage and identities before creating any output.
  std::map<int, std::vector<unsigned char>> tailMasks;
  std::string tailDefinition;
  Long64_t tailChecked = 0, tailRejected = 0, eventsAfterCoG = 0;
  std::set<std::string> uniqueInputs;
  int inputArgument = 3 + 2*Nenegry;
  for (int i = 0; i < Nenegry; ++i) {
    std::unique_ptr<hl_tail::Selection> selection;
    if (excludeTailEvents) {
      selection = std::make_unique<hl_tail::Selection>(tailResults / Form("%gGeV", energy[i]));
      tailDefinition = selection->definition();
    }
    for (int j = 0; j < energy_files[i]; ++j, ++inputArgument) {
      const auto input = std::filesystem::canonical(argv[inputArgument]).string();
      hl_tail::require(uniqueInputs.insert(input).second, "duplicate calibrated input " + input);
      hl_tail::require(std::filesystem::weakly_canonical(argv[1]) != input, "output would overwrite input");
      if (selection) {
        auto mask = selection->mask(input);
        tailChecked += mask.size();
        tailRejected += std::count(mask.begin(), mask.end(), 1);
        tailMasks.emplace(inputArgument, std::move(mask));
      }
    }
  }
  cout << "HL tail selection: " << (excludeTailEvents ? "exclude" : "keep")
       << "; checked=" << tailChecked << "; rejected=" << tailRejected << endl;


	// double cycleID, triggerID;
	// vector<int> *cellIDs = nullptr;
	// vector<int> *BCIDs = nullptr;
	// vector<int> *hitTags = nullptr;
	// vector<int> *gainTags = nullptr;
	// vector<double> *charges = nullptr;
	// vector<double> *times = nullptr;
	// vector<double> *temp = nullptr;
	// vector<double> *posX = nullptr;
	// vector<double> *posY = nullptr;
	// vector<double> *posZ = nullptr;

	// double cycleID_ssa, triggerID_ssa;
	// vector<int> *cellIDs_ssa = nullptr;
	// vector<int> *BCIDs_ssa = nullptr;
	// vector<int> *hitTags_ssa = nullptr;
	// vector<int> *gainTags_ssa = nullptr;
	// vector<double> *charges_ssa = nullptr;
	// vector<double> *times_ssa = nullptr;
	// vector<double> *temp_ssa = nullptr;
	// vector<double> *posX_ssa = nullptr;
	// vector<double> *posY_ssa = nullptr;
	// vector<double> *posZ_ssa = nullptr;
	// vector<int> *ssaTag_ssa = nullptr;

  double EnergyDep;
  vector<int> *cellID = nullptr;
  vector<double> *Hit_Energy = nullptr;
  vector<double> *Hit_X = nullptr;
	vector<double> *Hit_Y = nullptr;
	vector<double> *Hit_Z = nullptr;
  vector<double> *NewTemperature = nullptr;
	


	const int layerNu = 32;
	const int chipNu = 6;
	const int channelNu = 36;
	const int rowNu = 5;
	const int colNu = 42;
	const int doublelayerNu = 2;

  const int range_maximum = 12000;
  const int range_maximum_PS = 500;
  const double binWidth_PS = 0.1;



	TFile fileout(argv[1],"RECREATE");
  hl_tail::require(!fileout.IsZombie(), "cannot create output ROOT");
  TParameter<int>("hl_tail_excluded", int(excludeTailEvents)).Write();
  TNamed("hl_tail_status", "incomplete").Write();
  fileout.mkdir("beforeEventCut");
  fileout.mkdir("afterEventCut");
  fileout.cd();
	// gain_histo->Write();

  string dirName[2] = {"beforeEventCut", "afterEventCut"};
  string saveName[2] = {"", "cut_"};

  double edep_mean=0, edep_sigma=0, nhit_mean=0, nhit_sigma=0;


  for (int eventCut = 0; eventCut < 2; ++eventCut) {
    int irawfilenum = 3 + 2*Nenegry;
    // 0 : no cut,  1 : after cut


	// dataを入れるもの
  TH1F* energy_deposition[Nenegry];
  TH2F* hitmap[Nenegry][layerNu];
  TH1F* number_of_hits[Nenegry];
  TH2F* hit_vs_e[Nenegry];
  TH2F* hit_vs_e_per_layer[Nenegry][layerNu];
  TH2F* layer_vs_edep[Nenegry];
  TH2F* layer_vs_nhits[Nenegry];
  TH1F* hit_per_layer[Nenegry][layerNu];
  TH1F* edep_per_layer[Nenegry][layerNu];
  TH2F* cog[Nenegry][layerNu];
  TH1F* shower_radiusRMS[Nenegry];
  TH1F* shower_radius90[Nenegry];
  TH2F* layer_vs_rRMS[Nenegry];
  TH2F* layer_vs_r90[Nenegry];
  TH1F* edep_1hit[Nenegry][2];
  TH2F* layer_vs_temp[Nenegry];
  TH2F* firstLayerHit_vs_cog[Nenegry][2];
  // TH2F* edep_vs_rRMS[Nenegry];
  // TH2F* edep_vs_r90[Nenegry];
  for (int i = 0; i < Nenegry; ++i) {
    string histo_title = energy[i]<1 ? "0.5 GeV energy deposition" : Form("%g GeV energy deposition",energy[i]);
    int nbin = energy[i]>5 ? range_maximum : range_maximum_PS/binWidth_PS;
    int max_range = energy[i]>5 ? range_maximum : range_maximum_PS;
    energy_deposition[i] = new TH1F(Form("energy_deposition_%d",i),Form("%s",histo_title.c_str()),nbin,0,max_range);
    energy_deposition[i]->SetXTitle("Reconstructed Energy [MeV]");
    
    number_of_hits[i] = new TH1F(Form("nhits_%d",i),Form("%g GeV number of hits",energy[i]),3000,0,3000);
    number_of_hits[i]->SetXTitle("number of hits");

    hit_vs_e[i] = new TH2F(Form("hit_vs_e_%d",i),Form("%g GeV nhits vs. edep",energy[i]), nbin,0,max_range, 3000,0,3000);
    hit_vs_e[i]->SetXTitle("Detected Energy [MeV]");
    hit_vs_e[i]->SetYTitle("number of hits");

    double edep_max = energy[i]>5 ? 1000 : 100;
    layer_vs_edep[i] = new TH2F(Form("layer_vs_edep_%d",i),Form("%g GeV layer vs. edep",energy[i]), layerNu,0,layerNu, edep_max,0,edep_max);
    layer_vs_edep[i]->SetXTitle("layer");
    layer_vs_edep[i]->SetYTitle("Detected Energy [MeV]");

    layer_vs_nhits[i] = new TH2F(Form("layer_vs_nhits_%d",i),Form("%g GeV layer vs. number of hits",energy[i]), layerNu,0,layerNu, 100,0,100);
    layer_vs_nhits[i]->SetXTitle("layer");
    layer_vs_nhits[i]->SetYTitle("number of hits");

    layer_vs_temp[i] = new TH2F(Form("layer_vs_temp_%d",i),Form("%g GeV layer vs. temperature",energy[i]), layerNu,0,layerNu, 120,18,30);
    layer_vs_temp[i]->SetXTitle("layer");
    layer_vs_temp[i]->SetYTitle("temperature [#circC]");
    
    for (int ilayer = 0; ilayer < layerNu; ++ilayer) {
      hit_vs_e_per_layer[i][ilayer] = new TH2F(Form("hit_vs_e_per_layer_%d",ilayer),Form("%g GeV layer %d nhits vs. edep",energy[i], ilayer), edep_max,0,edep_max, 100,0,100);
      hit_vs_e_per_layer[i][ilayer]->SetXTitle("Detected Energy [MeV]");
      hit_vs_e_per_layer[i][ilayer]->SetYTitle("number of hits");
      edep_per_layer[i][ilayer] = new TH1F(Form("edep_per_layer_%d",ilayer),Form("%g GeV layer %d edep",energy[i],ilayer), edep_max,0,edep_max);
      edep_per_layer[i][ilayer]->SetXTitle("Detected Energy [MeV]");
      hit_per_layer[i][ilayer] = new TH1F(Form("hit_per_layer_%d",ilayer),Form("%g GeV layer %d number of hits",energy[i],ilayer), 100,0,100);
      hit_per_layer[i][ilayer]->SetXTitle("number of hits");

      hitmap[i][ilayer] = new TH2F(Form("hitmap_%dGeV_layer%d",i,ilayer),Form("hitmap %g GeV layer %d",energy[i],ilayer),226,-113,113,226,-113,113);
      cog[i][ilayer] = new TH2F(Form("cog_%dGeV_layer_%d",i,ilayer),Form("center of gravity %g GeV layer %d",energy[i],ilayer),226,-113,113,226,-113,113);
    }

    shower_radiusRMS[i] = new TH1F(Form("shower_radiusRMS_%d",i),Form("%g GeV shower radius (RMS)",energy[i]),2000,0,200);
    shower_radiusRMS[i]->SetXTitle("radius [mm]");
    shower_radius90[i] = new TH1F(Form("shower_radius90_%d",i),Form("%g GeV shower radius R90",energy[i]),2000,0,200);
    shower_radius90[i]->SetXTitle("radius [mm]");
    layer_vs_r90[i] = new TH2F(Form("layer_vs_r90_%d",i),Form("%g GeV layer vs. r90",energy[i]), layerNu,0,layerNu, 2000,0,200);
    layer_vs_r90[i]->SetXTitle("layer");
    layer_vs_r90[i]->SetYTitle("radius [mm]");
    layer_vs_rRMS[i] = new TH2F(Form("layer_vs_rRMS_%d",i),Form("%g GeV layer vs. rRMS",energy[i]), layerNu,0,layerNu, 2000,0,200);
    layer_vs_rRMS[i]->SetXTitle("layer");
    layer_vs_rRMS[i]->SetYTitle("radius [mm]");
    // edep_vs_rRMS[i] = new TH2F(Form("edep_vs_rRMS_%d",i),Form("%g GeV edep vs. rRMS",energy[i]), nbin,0,max_range, 2000,0,200);
    // edep_vs_rRMS[i]->SetXTitle("layer");
    // edep_vs_rRMS[i]->SetYTitle("radius [mm]");
    // edep_vs_r90[i] = new TH2F(Form("edep_vs_r90_%d",i),Form("%g GeV edep vs. rRMS",energy[i]), nbin,0,max_range, 2000,0,200);
    // edep_vs_r90[i]->SetXTitle("layer");
    // edep_vs_r90[i]->SetYTitle("radius [mm]");

    edep_1hit[i][1] = new TH1F(Form("edep_1hit_15um_%d",i),Form("%g GeV Edep of 1 channel (15 um)",energy[i]), 12000,0,12);
    edep_1hit[i][1]->SetXTitle("[MeV]");
    edep_1hit[i][0] = new TH1F(Form("edep_1hit_10um_%d",i),Form("%g GeV Edep of 1 channel (10 um)",energy[i]), 12000,0,12);
    edep_1hit[i][0]->SetXTitle("[MeV]");

    firstLayerHit_vs_cog[i][0] = new TH2F(Form("firstLayerHit_vs_cog_%d_layer9",i),Form("%g GeV firstLayerHit vs cog 9",energy[i]), 2000,0,200, 2000,0,200);
    firstLayerHit_vs_cog[i][0]->SetXTitle("layer 0 cog from center [mm]");
    firstLayerHit_vs_cog[i][0]->SetYTitle("layer 9 cog from center [mm]");
    firstLayerHit_vs_cog[i][1] = new TH2F(Form("firstLayerHit_vs_cog_%d_layer10",i),Form("%g GeV firstLayerHit vs cog 10",energy[i]), 2000,0,200, 2000,0,200);
    firstLayerHit_vs_cog[i][1]->SetXTitle("layer 0 cog from center [mm]");
    firstLayerHit_vs_cog[i][1]->SetYTitle("layer 10 cog from center [mm]");
	}
  
	

	// runごとにつくるもの
	


  



	// 保存形式
  






  // vector<string> skipFiles{"ECAL_Run196_20230504_123821.root", "ECAL_Run197_20230504_135137.root", "ECAL_Run194_20230504_082851.root", "ECAL_Run195_20230504_104136.root", "AHCAL_Run133_20230501_081117.root"};


	// data をとってきてる
	for(int ienergy=0; ienergy<Nenegry; ienergy++){
		if(Nenegry>1) cout << energy[ienergy] << " GeV" << endl;

    TH1F* edep_channel[layerNu][chipNu][channelNu];
    for (int i_layer = 0; i_layer < layerNu; ++i_layer) {
      for (int i_chip = 0; i_chip < chipNu; ++i_chip) {
        for (int i_channel = 0; i_channel < channelNu; ++i_channel) {
          edep_channel[i_layer][i_chip][i_channel] = new TH1F(Form("edep_channel_%d_%d_%d",i_layer, i_chip, i_channel),Form("%g GeV layer%d chip%d channel%d",energy[ienergy], i_layer, i_chip, i_channel),2000,0,2);
        }
      }
    }

    TFile *filein[energy_files[ienergy]];
    TTree *tree[energy_files[ienergy]];
    Long64_t entry_max[energy_files[ienergy]];
    for(int i=0; i<energy_files[ienergy]; i++){
	  	filein[i] = new TFile(argv[irawfilenum+i]);
	  	tree[i] = (TTree*) filein[i]->Get("Calib_Hit");
      hl_tail::require(!filein[i]->IsZombie() && tree[i], "missing Calib_Hit input");
      entry_max[i] = tree[i]->GetEntries();
    }

    for(int irawfile=0; irawfile<energy_files[ienergy]; irawfile++){
      cout << irawfile << "/" << energy_files[ienergy] << endl;

      // string fileName = argv[irawfilenum+irawfile];
      // auto result = find(skipFiles.begin(), skipFiles.end(), fileName);
      // if (result != skipFiles.end()) continue;
      
		  tree[irawfile]->SetBranchAddress("CellID", &cellID);
		  tree[irawfile]->SetBranchAddress("Hit_Energy", &Hit_Energy);
		  tree[irawfile]->SetBranchAddress("TotalEnergyDep", &EnergyDep);
		  tree[irawfile]->SetBranchAddress("Hit_X", &Hit_X);
		  tree[irawfile]->SetBranchAddress("Hit_Y", &Hit_Y);
		  tree[irawfile]->SetBranchAddress("Hit_Z", &Hit_Z);
		  tree[irawfile]->SetBranchAddress("NewTemperature", &NewTemperature);

      for(Long64_t ientry=0; ientry<entry_max[irawfile]; ientry++){
        if (excludeTailEvents && tailMasks.at(irawfilenum+irawfile).at(ientry)) continue;
        // if(ientry%1000==0) cout << ientry << "/" << entry_max[irawfile] << endl;
        hl_tail::require(tree[irawfile]->GetEntry(ientry) > 0, "cannot read calibrated hit event");
        

        double sumEdep = 0;
        double sumEdep_all = 0;
        double cog_x[32] = {0};
        double cog_y[32] = {0};
        int nhits[32] = {0};
        int n_of_hits[2] = {0};
        double energies[32] = {0};
        double average_temperature[32] = {0};
        int nhit_firstLayer = 0;
        // vector<double> layerSSA, xSSA, ySSA, eSSA;
        double cut_nhit=0, cut_edep=EnergyDep;
        for(int ihit=0;ihit<Hit_Energy->size();ihit++){
          int _layerID = cellID->at(ihit)/1e5;
          int _chipID  = (cellID->at(ihit)%100000) /1e4;
          int _chanID  = cellID->at(ihit)%100;
          if(_layerID>=30) continue;
          if(_layerID==0) nhit_firstLayer++;
          if( (_chipID<0 || _chipID>5) || (_chanID<0 || _chanID>35) ) cout << "error in cellId " << cellID->at(ihit) << endl;
          if(Hit_Energy->at(ihit)<0) continue;
          n_of_hits[0]++;
          const int currentCellId = cellID->at(ihit);
          if(bool_only_best) if(bad_channels.find(currentCellId) != bad_channels.end()) continue;
          n_of_hits[1]++;
          cog_x[_layerID] += Hit_X->at(ihit) * Hit_Energy->at(ihit);
          cog_y[_layerID] += Hit_Y->at(ihit) * Hit_Energy->at(ihit);
          energies[_layerID] += Hit_Energy->at(ihit);
          sumEdep_all += Hit_Energy->at(ihit);
          cut_nhit++;
        }
        double distance_cog0 = sqrt(pow(cog_x[0]/energies[0],2)+pow(cog_y[0]/energies[0],2));
        double distance_cog9 = sqrt(pow(cog_x[9]/energies[9],2)+pow(cog_y[9]/energies[9],2));
        double distance_cog10 = sqrt(pow(cog_x[10]/energies[10],2)+pow(cog_y[10]/energies[10],2));
        firstLayerHit_vs_cog[ienergy][0]->Fill(distance_cog0, distance_cog9);
        firstLayerHit_vs_cog[ienergy][1]->Fill(distance_cog0, distance_cog10);
        // if(nhit_firstLayer>1) continue;
        if(!(cog_position_check(cog_x[9]/energies[9], cog_y[9]/energies[9], cog_range) && cog_position_check(cog_x[10]/energies[10], cog_y[10]/energies[10], cog_range))) continue;
        if (eventCut == 0) ++eventsAfterCoG;
        if(eventCut==1 && eventCutConditions(sumEdep_all, cut_nhit, edep_mean, edep_sigma, nhit_mean, nhit_sigma)) continue;
        // energy_deposition[ienergy]->Fill(sumEdep_all);
        for(int ihit=0;ihit<Hit_Energy->size();ihit++){
          int _layerID = cellID->at(ihit)/1e5;
          int _chipID  = (cellID->at(ihit)%100000) /1e4;
          int _chanID  = cellID->at(ihit)%100;
          if(_layerID>=30) continue;
          if( (_chipID<0 || _chipID>5) || (_chanID<0 || _chanID>35) ) cout << "error in cellId " << cellID->at(ihit) << endl;
          if(Hit_Energy->at(ihit)<0) continue;
          edep_channel[_layerID][_chipID][_chanID]->Fill(Hit_Energy->at(ihit));
          // layerSSA.push_back(_layerID);
          // xSSA.push_back(Hit_X->at(ihit));
          // ySSA.push_back(Hit_Y->at(ihit));
          // eSSA.push_back(Hit_Energy->at(ihit));
          const int currentCellId = cellID->at(ihit);
          if(bool_only_best) if(bad_channels.find(currentCellId) != bad_channels.end()) continue;
          sumEdep += Hit_Energy->at(ihit);

          nhits[_layerID]++;
          average_temperature[_layerID] += NewTemperature->at(ihit);

          int SiPMType = sipmtypes(_layerID);
          edep_1hit[ienergy][SiPMType]->Fill(Hit_Energy->at(ihit));
        }
        // number_of_hits[ienergy]->Fill(n_of_hits[1]);
        // hit_vs_e[ienergy]->Fill(sumEdep, n_of_hits[1]);
        // for(int i=0;i<layerNu;i++){
        //   hit_vs_e_per_layer[ienergy][i]->Fill(energies[i], nhits[i]);
        //   layer_vs_edep[ienergy]->Fill(i, energies[i]);
        //   layer_vs_nhits[ienergy]->Fill(i, nhits[i]);
        //   edep_per_layer[ienergy][i]->Fill(energies[i]);
        //   hit_per_layer[ienergy][i]->Fill(nhits[i]);
        // }
        // double radius = CalculateShowerRadiusRMS(Hit_X, Hit_Y, Hit_Energy);
        // SSAResult ssa_output = PerformStripSplitSSA(xSSA, ySSA, layerSSA, eSSA);
        // ShowerContainer shower_output = CalculateShowerRadius(ssa_output.x, ssa_output.y, ssa_output.layer, ssa_output.energy);
        // shower_radiusRMS[ienergy]->Fill(shower_output.rms_radius);
        // shower_radius90[ienergy]->Fill(shower_output.r90_radius);
        // // edep_vs_rRMS[ienergy]->Fill(sumEdep, shower_output.rms_radius);
        // // edep_vs_r90[ienergy]->Fill(sumEdep, shower_output.r90_radius);
        // for(int i=0;i<layerNu;i++){
        //   layer_vs_rRMS[ienergy]->Fill(i, shower_output.layers[i].rms_radius);
        //   layer_vs_r90[ienergy]->Fill(i, shower_output.layers[i].r90_radius);
        // }
        
        // if(cog_position_check(cog_x[9]/energies[9], cog_y[9]/energies[9], cog_range) && cog_position_check(cog_x[10]/energies[10], cog_y[10]/energies[10], cog_range) ) {
          energy_deposition[ienergy]->Fill(sumEdep);
          number_of_hits[ienergy]->Fill(n_of_hits[1]);
          hit_vs_e[ienergy]->Fill(sumEdep, n_of_hits[1]);
          for(int i=0;i<layerNu;i++){
            hit_vs_e_per_layer[ienergy][i]->Fill(energies[i], nhits[i]);
            layer_vs_edep[ienergy]->Fill(i, energies[i]);
            layer_vs_nhits[ienergy]->Fill(i, nhits[i]);
            layer_vs_temp[ienergy]->Fill(i, average_temperature[i]/nhits[i]);
            edep_per_layer[ienergy][i]->Fill(energies[i]);
            hit_per_layer[ienergy][i]->Fill(nhits[i]);
          }
        // }

        for (int ilayer = 0; ilayer < layerNu; ++ilayer) {
          cog[ienergy][ilayer]->Fill(cog_x[ilayer]/energies[ilayer], cog_y[ilayer]/energies[ilayer]);
        }
	  	}

      EnergyDep = 0;
      cellID = nullptr;
      Hit_Energy = nullptr;
      Hit_X = nullptr;
      Hit_Y = nullptr;
      Hit_Z = nullptr;
      delete filein[irawfile];
	  }

    hl_tail::require(energy_deposition[ienergy]->GetEntries() > 0, "no events survive tail/CoG/event selection");
    fileout.cd();
    // fileout.cd(Form("%s",dirName[eventCut].c_str()));
    if(eventCut==0) fileout.mkdir(Form("%dGeV", (int)energy[ienergy]));
    fileout.cd(Form("%dGeV", (int)energy[ienergy]));
    for (int i_layer = 0; i_layer < 30; ++i_layer) {
      for (int i_chip = 0; i_chip < chipNu; ++i_chip) {
        TCanvas* c1 = new TCanvas(Form("edep_Layer%d_Chip%d", i_layer, i_chip), Form("Layer%d Chip%d", i_layer, i_chip), 2560, 1440);
        c1->Divide(6, 6);
        for (int i_channel = 0; i_channel < channelNu; ++i_channel) {
          c1->cd();
          c1->cd(i_channel+1);
          edep_channel[i_layer][i_chip][i_channel]->Draw();
        }
        c1->Update();
        c1->Write(Form("%sedep_Layer%d_Chip%d", saveName[eventCut].c_str(),i_layer, i_chip));
        c1->SaveAs(Form("%s/%gGeV/raw/%s%gGeV_layer%dchip%d.png",argv[argc-1],energy[ienergy],saveName[eventCut].c_str(),energy[ienergy],i_layer,i_chip));
        delete c1;
        for (int i_channel = 0; i_channel < channelNu; ++i_channel) {
          delete edep_channel[i_layer][i_chip][i_channel];
        }
      }
    }
    fileout.cd();
    irawfilenum += energy_files[ienergy];
  }

  cout << "fitting histograms ... " << endl;

  fileout.cd();
  fileout.cd(Form("%s",dirName[eventCut].c_str()));
  gStyle->SetOptFit(1111111);

  TCanvas* C_res[Nenegry];
  TF1 *gaussian = new TF1("gaussian","gaus",200,range_maximum);
  // TF1 *gaussian_PS = new TF1("gaussian_PS","gaus",10,range_maximum_PS);
  double energy_mean[Nenegry], energy_sigma[Nenegry], energy_mean_error[Nenegry], energy_sigma_error[Nenegry];
  for(int ienergy=0; ienergy<Nenegry; ienergy++){
    C_res[ienergy] = new TCanvas(Form("Edep_%dGeV",(int)energy[ienergy]), Form("%g GeV energy deposit",energy[ienergy]), 1);
    C_res[ienergy]->cd();
    gStyle->SetOptFit(1111111);

    energy_deposition[ienergy]->GetXaxis()->SetRange(200,range_maximum);
    if(energy[ienergy]<=5) energy_deposition[ienergy]->GetXaxis()->SetRange(10/binWidth_PS,range_maximum_PS/binWidth_PS);
    double amp = energy_deposition[ienergy]->GetMaximum();
    double mean = energy_deposition[ienergy]->GetMean();
    double sigma = energy_deposition[ienergy]->GetStdDev();
    // Seed the 200 GeV shower peak without the broad low-energy component (MeV).
    if (energy[ienergy] == 200) {
      mean = 8000;
      sigma = 300;
    }
    double fit_range_low = 15 > mean-3*sigma ? 15 : mean-3*sigma;
    // double mean = energy_deposition[ienergy]->GetMaximumBin();
    // if(energy[ienergy]<=5){
    //   amp = 50;
    //   mean = energy[ienergy] * 60;
    // }
    
    gaussian->SetParameter(0,amp);
    gaussian->SetParameter(1,mean);
    gaussian->SetParameter(2,sigma);
    energy_deposition[ienergy]->Fit("gaussian","","NQ",fit_range_low,mean+3*sigma);
    mean = gaussian->GetParameter(1);
    sigma = gaussian->GetParameter(2);
    fit_range_low = 15 > mean-1.5*sigma ? 15 : mean-1.5*sigma;
    energy_deposition[ienergy]->Fit("gaussian","","NQ",fit_range_low,mean+1.5*sigma);
    // if(energy[ienergy]>5) energy_deposition[ienergy]->Fit("gaussian","","NQ",mean-50*(energy[ienergy]/20),mean+50*(energy[ienergy]/20));
    // else energy_deposition[ienergy]->Fit("gaussian","","NQ",mean-20*energy[ienergy],mean+20*energy[ienergy]);
    // if(energy[ienergy] == 20) energy_deposition[ienergy]->Fit("gaussian","","NQ",1050,1250);

    //////////////////////////////////
    // int histo_range_minimum = gaussian->GetParameter(1) - gaussian->GetParameter(2) * 7 > 15 ? gaussian->GetParameter(1) - gaussian->GetParameter(2) * 7 : 15;
    // int histo_range_maximum = gaussian->GetParameter(1) + gaussian->GetParameter(2) * 7;
    // energy_deposition[ienergy]->GetXaxis()->SetRange(histo_range_minimum,histo_range_maximum);
    //////////////////////////////////

    energy_deposition[ienergy]->Draw();
    gaussian->Draw("same");

    fileout.cd();
    fileout.cd(Form("%s",dirName[eventCut].c_str()));
    C_res[ienergy]->Write();
    energy_deposition[ienergy]->Write(Form("edep_%dGeV",(int)energy[ienergy]));
    gaussian->Write("fit_gaus");
    
    fileout.cd();
    fileout.cd(Form("%s",dirName[eventCut].c_str()));
    energy_mean[ienergy] = gaussian->GetParameter(1);
    energy_sigma[ienergy] = gaussian->GetParameter(2);
    energy_mean_error[ienergy] = gaussian->GetParError(1);
    energy_sigma_error[ienergy] = gaussian->GetParError(2);

    edep_mean=energy_mean[ienergy];
    edep_sigma=energy_sigma[ienergy];

    delete C_res[ienergy];    
  }


  
  fileout.cd();
  fileout.cd(Form("%s",dirName[eventCut].c_str()));
  


  for(int ienergy=0; ienergy<Nenegry; ienergy++){
    TCanvas *C_cog = new TCanvas(Form("C_cog_%d",ienergy), Form("center of gravity %g GeV",energy[ienergy]), 2560,1440); 
    C_cog->Divide(6,5);
    C_cog->cd();
    for (int ilayer = 0; ilayer < 30; ++ilayer) {
      C_cog->cd(ilayer+1);
      cog[ienergy][ilayer]->Draw("colz");
    }
    C_cog->Write(Form("C_cog_%dGeV",(int)energy[ienergy]));
    C_cog->SaveAs(Form("%s/%gGeV/%scog_%gGeV.png",argv[argc-1],energy[ienergy],saveName[eventCut].c_str(),energy[ienergy]));

    delete C_cog;
  }

  for(int ienergy=0; ienergy<Nenegry; ienergy++){
    TCanvas *C_cog_vs_first = new TCanvas(Form("C_cog_vs_first_%d",ienergy), Form("center of gravity %g GeV",energy[ienergy]), 2560,1440); 
    C_cog_vs_first->Divide(2,1);
    C_cog_vs_first->cd();
    C_cog_vs_first->cd(1);
    firstLayerHit_vs_cog[ienergy][0]->Draw("colz");
    C_cog_vs_first->cd(2);
    firstLayerHit_vs_cog[ienergy][1]->Draw("colz");
    C_cog_vs_first->SaveAs(Form("%s/%gGeV/%sfirstLayerHit_vs_cog.png",argv[argc-1],energy[ienergy],saveName[eventCut].c_str()));
  }

  fileout.cd();
  fileout.cd(Form("%s",dirName[eventCut].c_str()));
  for(int ienergy=0; ienergy<Nenegry; ienergy++){
    TCanvas *C_hit_vs_e = new TCanvas(Form("C_hit_vs_e_%d",ienergy), Form("%g GeV number of hits vs energy deposit",energy[ienergy]), 2560,1440); 
    C_hit_vs_e->Divide(6,5);
    C_hit_vs_e->cd();
    for (int ilayer = 0; ilayer < 30; ++ilayer) {
      C_hit_vs_e->cd(ilayer+1);
      hit_vs_e_per_layer[ienergy][ilayer]->Draw("colz");
      hit_vs_e_per_layer[ienergy][ilayer]->Write(Form("hit_vs_e_%dGeV_layer%d",(int)energy[ienergy],ilayer));
    }
    C_hit_vs_e->Write(Form("hit_vs_e_per_layer_%dGeV",(int)energy[ienergy]));
    C_hit_vs_e->SaveAs(Form("%s/%gGeV/%shit_vs_e_per_layer_%gGeV.png",argv[argc-1],energy[ienergy],saveName[eventCut].c_str(),energy[ienergy]));

    delete C_hit_vs_e;
  }
  for(int ienergy=0; ienergy<Nenegry; ienergy++){
    TCanvas *C_edeps = new TCanvas(Form("C_edeps_%d",ienergy), Form("%g GeV energy deposits",energy[ienergy]), 2560,1440); 
    C_edeps->Divide(6,5);
    C_edeps->cd();
    for (int ilayer = 0; ilayer < 30; ++ilayer) {
      C_edeps->cd(ilayer+1);
      edep_per_layer[ienergy][ilayer]->Draw();
      edep_per_layer[ienergy][ilayer]->Write(Form("edep_%dGeV_layer%d",(int)energy[ienergy],ilayer));
    }
    C_edeps->Write(Form("edep_per_layer_%dGeV",(int)energy[ienergy]));
    C_edeps->SaveAs(Form("%s/%gGeV/%sedep_per_layer_%gGeV.png",argv[argc-1],energy[ienergy],saveName[eventCut].c_str(),energy[ienergy]));

    delete C_edeps;
  }
  for(int ienergy=0; ienergy<Nenegry; ienergy++){
    TCanvas *C_nhits = new TCanvas(Form("C_nhits_%d",ienergy), Form("%g GeV number of hits",energy[ienergy]), 2560,1440); 
    C_nhits->Divide(6,5);
    C_nhits->cd();
    for (int ilayer = 0; ilayer < 30; ++ilayer) {
      C_nhits->cd(ilayer+1);
      hit_per_layer[ienergy][ilayer]->Draw();
      hit_per_layer[ienergy][ilayer]->Write(Form("nhits_%dGeV_layer%d",(int)energy[ienergy],ilayer));
    }
    C_nhits->Write(Form("nhits_per_layer_%dGeV",(int)energy[ienergy]));
    C_nhits->SaveAs(Form("%s/%gGeV/%snhits_per_layer_%gGeV.png",argv[argc-1],energy[ienergy],saveName[eventCut].c_str(),energy[ienergy]));

    delete C_nhits;
  }
  fileout.cd();
  fileout.cd(Form("%s",dirName[eventCut].c_str()));


  TF1 *gaussian_hit = new TF1("gaussian_hit","gaus",0,1500);
  for(int ienergy=0; ienergy<Nenegry; ienergy++){
    fileout.cd();
    fileout.cd(Form("%s",dirName[eventCut].c_str()));
    TCanvas* C_e_summary = new TCanvas(Form("Edep_%gGeV_summary",energy[ienergy]), Form("%g GeV",energy[ienergy]), 2560,1440); 
    C_e_summary->cd();
    C_e_summary->Divide(4,2);

    C_e_summary->cd(1);
    hit_vs_e[ienergy]->Draw("colz");
    hit_vs_e[ienergy]->Write(Form("hit_vs_e_%dGeV",(int)energy[ienergy]));
    C_e_summary->cd(2);
    gStyle->SetOptFit(1111111);
    energy_deposition[ienergy]->Draw();

    C_e_summary->cd(3);
    number_of_hits[ienergy]->Draw();
    double amp = number_of_hits[ienergy]->GetMaximum();
    double mean = number_of_hits[ienergy]->GetMean();
    double sigma = number_of_hits[ienergy]->GetStdDev();
    double fit_range_low = 7 > mean-3*sigma ? 7 : mean-3*sigma;
    gaussian_hit->SetParameter(0,amp);
    gaussian_hit->SetParameter(1,mean);
    gaussian_hit->SetParameter(2,sigma);
    number_of_hits[ienergy]->Fit("gaussian_hit","","NQ",fit_range_low,mean+3*sigma);
    mean = gaussian_hit->GetParameter(1);
    sigma = gaussian_hit->GetParameter(2);
    fit_range_low = 15 > mean-1.5*sigma ? 15 : mean-1.5*sigma;
    number_of_hits[ienergy]->Fit("gaussian_hit","","NQ",fit_range_low,mean+1.5*sigma);
    number_of_hits[ienergy]->Write(Form("nhits_%dGeV", (int)energy[ienergy]));
    nhit_mean = gaussian_hit->GetParameter(1);
    nhit_sigma = gaussian_hit->GetParameter(2);
    gaussian_hit->Write("fit_gaus_nhit");

    C_e_summary->cd(4);
    gPad->SetLogz(1);
    layer_vs_edep[ienergy]->Draw("colz");
    layer_vs_edep[ienergy]->Write(Form("layer_vs_edep_%dGeV", (int)energy[ienergy]));

    C_e_summary->cd(5);
    edep_1hit[ienergy][0]->GetXaxis()->SetRangeUser(0,2);
    edep_1hit[ienergy][0]->Draw();
    edep_1hit[ienergy][0]->Write(Form("edep_1hit_10um"));
    C_e_summary->cd(6);
    edep_1hit[ienergy][1]->GetXaxis()->SetRangeUser(0,2);
    edep_1hit[ienergy][1]->Draw();
    edep_1hit[ienergy][1]->Write(Form("edep_1hit_15um"));


    // 1 hit (10 15 um)
    // r shower
    // center og gravity

    C_e_summary->cd(7);
    gPad->SetLogz(1);
    layer_vs_temp[ienergy]->Draw("colz");
    layer_vs_temp[ienergy]->Write(Form("layer_vs_temp_%dGeV", (int)energy[ienergy]));

    C_e_summary->cd(8);
    gPad->SetLogz(1);
    layer_vs_nhits[ienergy]->Draw("colz");
    layer_vs_nhits[ienergy]->Write(Form("layer_vs_nhits_%dGeV", (int)energy[ienergy]));


    C_e_summary->Write();
    C_e_summary->SaveAs(Form("%s/%ssummary_%gGeV.png",argv[argc-1],saveName[eventCut].c_str(),energy[ienergy]));


    delete C_e_summary;
  }


  

  for (int i = 0; i < Nenegry; ++i) {
    delete energy_deposition[i];
    delete number_of_hits[i];
    delete hit_vs_e[i];
    delete layer_vs_edep[i];
    delete layer_vs_nhits[i];
    delete layer_vs_temp[i];
    
    
    for (int ilayer = 0; ilayer < layerNu; ++ilayer) {
      delete hitmap[i][ilayer];
      delete hit_vs_e_per_layer[i][ilayer];
      delete hit_per_layer[i][ilayer];
      delete edep_per_layer[i][ilayer];
      delete cog[i][ilayer];
    }

    delete shower_radiusRMS[i];
    delete shower_radius90[i];
    delete layer_vs_r90[i];
    delete layer_vs_rRMS[i];

    delete edep_1hit[i][0];
    delete edep_1hit[i][1];
	}

  }
  
  fileout.cd();
  TParameter<int>("hl_tail_excluded", int(excludeTailEvents)).Write();
  TParameter<Long64_t>("hl_tail_checked_events", tailChecked).Write();
  TParameter<Long64_t>("hl_tail_rejected_events", tailRejected).Write();
  TParameter<Long64_t>("hl_tail_events_after_cog", eventsAfterCoG).Write();
  TNamed("hl_tail_source", excludeTailEvents ? std::filesystem::canonical(tailResults).c_str() : "none").Write();
  TNamed("hl_tail_definition", tailDefinition.c_str()).Write();
  TNamed("hl_tail_status", "complete").Write();
  return 0;
} catch (const std::exception& error) {
  std::cerr << error.what() << std::endl;
  return 1;
}
