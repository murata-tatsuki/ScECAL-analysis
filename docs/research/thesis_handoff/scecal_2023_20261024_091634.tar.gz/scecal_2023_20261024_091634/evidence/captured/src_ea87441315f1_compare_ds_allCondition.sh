#! /bin/bash
slurm_log_dir=$(realpath -m -- "$(dirname -- "${BASH_SOURCE[0]}")/../log/resolution")
mkdir -p -- "$slurm_log_dir"

source /megraid01/users/data_beamtest/analysis/ECAL_Analysis_LCIO/run/global_config

paralell_jobs () {
  Calib_path=$1
  cog_rage=$2

  for txt in $( ls ${Calib_path}/*_${cog_rage}mm.root ); do
    echo -n ${txt} >> ../tmp/compare_resolution.txt
    echo -n " " >> ../tmp/compare_resolution.txt
  done
}


mkdir -p "${slurm_log_dir}/compare"

rm ../tmp/compare_resolution.txt
touch ../tmp/compare_resolution.txt


thre=threshold
path_suffix=dataThre

root_path=../result/resolution/comparsion
fig_path=../result/resolution/figures/comparsion/${path_suffix}
# fig_path=../result/resolution/figures/comparsion/${cog_rage}mm


mkdir -p ${fig_path}
mkdir -p ${root_path}

# count_data=$(ls ../result/resolution/data/${cog_rage}mm -U1 | wc -l)
# echo -n ${count_data} >> ../tmp/compare_resolution.txt
# echo -n " " >> ../tmp/compare_resolution.txt

echo -n 8 >> ../tmp/compare_resolution.txt
echo -n " " >> ../tmp/compare_resolution.txt

count_sim=$(ls ../result/resolution/data/200mm -U1 | wc -l)
echo -n ${count_sim} >> ../tmp/compare_resolution.txt
echo -n " " >> ../tmp/compare_resolution.txt


cog_rage=200
paralell_jobs ../result/resolution/data/${cog_rage}mm ${cog_rage}
paralell_jobs ../result/resolution/simulation/${thre}/${cog_rage}mm ${cog_rage}

cog_rage=20
paralell_jobs ../result/resolution/data/${cog_rage}mm ${cog_rage}
paralell_jobs ../result/resolution/simulation/${thre}/${cog_rage}mm ${cog_rage}

cog_rage=10
paralell_jobs ../result/resolution/data/${cog_rage}mm ${cog_rage}
paralell_jobs ../result/resolution/simulation/${thre}/${cog_rage}mm ${cog_rage}

cog_rage=5
paralell_jobs ../result/resolution/data/${cog_rage}mm ${cog_rage}
paralell_jobs ../result/resolution/simulation/${thre}/${cog_rage}mm ${cog_rage}



var=`cat ../tmp/compare_resolution.txt`
# ./threshold_finding ../result/threshold/analyze_${txt}.root ${var} ${fig_path}
# ./MultiEnergyAnalysis ${root_path}/comparison_${path_suffix}.root ${var} ${fig_path}
sbatch -o "${slurm_log_dir}/compare/test-%A.out" --error="${slurm_log_dir}/compare/test-%A.err" execute_paralell.sl ./MultiEnergyAnalysis ${root_path}/comparison_${cog_rage}mm.root ${var} ${fig_path} --skip-channel-plots
